package com.tekion.lookuphelper;

import com.google.common.collect.Lists;
import com.tekion.core.es.common.impl.TekSearchRequest;
import com.tekion.lookuphelper.dto.request.*;
import com.tekion.lookuphelper.dto.response.LookupEntity;
import com.tekion.lookuphelper.dto.response.LookupSearchResponse;
import com.tekion.lookuphelper.lookupConsumerClient.LookupServiceClient;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static com.tekion.lookuphelper.LookupConsumerAsset.GL_ACCOUNT_ASSET;
import static com.tekion.lookuphelper.MultiLookupServiceV2Test.Utils.*;

@ExtendWith(MockitoExtension.class)
class MultiLookupServiceV2Test {
    @InjectMocks
    MultiLookupServiceV2 multiLookupServiceV2;
    @Mock
    LookupServiceProvider lookupServiceProvider;
    @Mock
    LookupServiceClient lookupServiceClient;

    @Test
    public void lookupByIds_WhenLookUpServiceIsNotNull(){
        BulkLookupRequestByIds bulkLookupRequestByIds = getBulkLookupRequestByIds();
        Map<? extends ILookupAsset, List<LookupEntity>> expectedResultMap = getResultMap();

        Mockito.when(lookupServiceProvider.getServiceForLookupAsset(GL_ACCOUNT_ASSET)).thenReturn(new DummyAbstractLookupService());

        Map<? extends ILookupAsset, List<LookupEntity>> actualResultMap =
                multiLookupServiceV2.lookupByIds(bulkLookupRequestByIds);

        Assertions.assertEquals(expectedResultMap, actualResultMap);

    }

    @Test
    public void lookupByIds_WhenLookUpServiceIsNull(){
        BulkLookupRequestByIds bulkLookupRequestByIds = getBulkLookupRequestByIds();
        Map<? extends ILookupAsset, List<LookupEntity>> expectedResultMap = getResultMap();

        Mockito.when(lookupServiceProvider.getServiceForLookupAsset(GL_ACCOUNT_ASSET)).thenReturn(null);
        Mockito.when(lookupServiceClient.lookupByIds(Mockito.any())).thenReturn(getResultMap());

        Map<? extends ILookupAsset, List<LookupEntity>> actualResultMap =
                multiLookupServiceV2.lookupByIds(bulkLookupRequestByIds);

        Assertions.assertEquals(expectedResultMap, actualResultMap);

    }

    @Test
    public void lookupByNumbers_WhenLookUpServiceIsNotNull(){
        BulkLookupRequestByNumbers bulkLookupRequestByNumbers = getBulkLookupRequestByNumbers();
        Map<? extends ILookupAsset, List<LookupEntity>> expectedResultMap = getResultMap();

        Mockito.when(lookupServiceProvider.getServiceForLookupAsset(GL_ACCOUNT_ASSET)).thenReturn(new DummyAbstractLookupService());

        Map<? extends ILookupAsset, List<LookupEntity>> actualResultMap =
                multiLookupServiceV2.lookupByNumber(bulkLookupRequestByNumbers);

        Assertions.assertEquals(expectedResultMap, actualResultMap);

    }

    @Test
    public void lookupByNumbers_WhenLookUpServiceIsNull(){
        BulkLookupRequestByNumbers bulkLookupRequestByNumbers = getBulkLookupRequestByNumbers();
        Map<? extends ILookupAsset, List<LookupEntity>> expectedResultMap = getResultMap();

        Mockito.when(lookupServiceProvider.getServiceForLookupAsset(GL_ACCOUNT_ASSET)).thenReturn(null);
        Mockito.when(lookupServiceClient.lookupByNumbers(Mockito.any())).thenReturn(getResultMap());

        Map<? extends ILookupAsset, List<LookupEntity>> actualResultMap =
                multiLookupServiceV2.lookupByNumber(bulkLookupRequestByNumbers);

        Assertions.assertEquals(expectedResultMap, actualResultMap);

    }

    @Test
    public void lookupBySearch_WhenLookUpServiceIsNotNull(){
        BulkLookupRequestBySearch bulkLookupRequestBySearch = getBulkLookupRequestBySearch();
        Map<? extends ILookupAsset, LookupSearchResponse> expectedResultMap = getResultMapForLookupBySearch();

        Mockito.when(lookupServiceProvider.getServiceForLookupAsset(GL_ACCOUNT_ASSET)).thenReturn(new DummyAbstractLookupService());

        Map<? extends ILookupAsset, LookupSearchResponse> actualResultMap =
                multiLookupServiceV2.lookupBySearch(bulkLookupRequestBySearch);

        Assertions.assertEquals(expectedResultMap, actualResultMap);

    }

    @Test
    public void lookupBySearch_WhenLookUpServiceIsNull() {
        BulkLookupRequestBySearch bulkLookupRequestBySearch = getBulkLookupRequestBySearch();
        Map<? extends ILookupAsset, LookupSearchResponse> expectedResultMap = getResultMapForLookupBySearch();

        Mockito.when(lookupServiceProvider.getServiceForLookupAsset(GL_ACCOUNT_ASSET)).thenReturn(null);
        Mockito.when(lookupServiceClient.lookupBySearch(Mockito.any())).thenReturn(getResultMapForLookupBySearch());

        Map<? extends ILookupAsset, LookupSearchResponse> actualResultMap = multiLookupServiceV2.lookupBySearch(
                bulkLookupRequestBySearch);

        Assertions.assertEquals(expectedResultMap, actualResultMap);

    }
    private static class DummyAbstractLookupService extends AbstractLookupService {

        @Override
        public LookupSearchResponse lookupBySearch(LookupRequestBySearch lookupRequestBySearch) {
            return Utils.getLookupSearchResponse();
        }

        @Override
        public List<LookupEntity> lookupByNumber(LookupRequestByNumbers lookupRequestByNumbers) {
            return Utils.getLookupEntityList();
        }


        @Override
        public List<LookupEntity> lookupByIds(LookupRequestByIds lookupRequestByIds){
            return Utils.getLookupEntityList();
        }

        @Override
        protected Map doLookupByIds(BulkLookupRequestByIds bulkLookupRequestByIds) {
            return new HashMap<>();
        }

        @Override
        protected Map doLookupBySearch(BulkLookupRequestBySearch bulkLookupRequestBySearch) {
            return new HashMap<>();
        }

        @Override
        protected Map doLookupByNumber(BulkLookupRequestByNumbers bulkLookupRequestByNumbers) {
            return new HashMap<>();
        }

        @Override
        public List<ILookupAsset> getSupportedLookupAssets() {
            return Lists.newArrayList(GL_ACCOUNT_ASSET);
        }
    }

    public static class Utils{
        public static  BulkLookupRequestByIds getBulkLookupRequestByIds(){
            BulkLookupRequestByIds bulkLookupRequestByIds = new BulkLookupRequestByIds();
            bulkLookupRequestByIds.setLookupRequestByIds(new ArrayList<>());
            LookupRequestByIds lookupRequestByIds = new LookupRequestByIds();
            lookupRequestByIds.setIds(Collections.emptyList());
            lookupRequestByIds.setAssetType(GL_ACCOUNT_ASSET);
            lookupRequestByIds.setIncludeFields(Collections.emptyList());
            lookupRequestByIds.setExcludeFields(Collections.emptyList());
            lookupRequestByIds.setMiniResponse(false);
            bulkLookupRequestByIds.getLookupRequestByIds().add(lookupRequestByIds);
            return bulkLookupRequestByIds;
        }

        public static BulkLookupRequestByNumbers getBulkLookupRequestByNumbers(){
            BulkLookupRequestByNumbers bulkLookupRequestByNumbers = new BulkLookupRequestByNumbers();
            bulkLookupRequestByNumbers.setLookupRequestByNumbers(new ArrayList<>());
            LookupRequestByNumbers lookupRequestByNumbers = new LookupRequestByNumbers();
            lookupRequestByNumbers.setNumbers(Collections.emptyList());
            lookupRequestByNumbers.setAssetType(GL_ACCOUNT_ASSET);
            lookupRequestByNumbers.setIncludeFields(Collections.emptyList());
            lookupRequestByNumbers.setExcludeFields(Collections.emptyList());
            lookupRequestByNumbers.setMiniResponse(false);
            bulkLookupRequestByNumbers.getLookupRequestByNumbers().add(lookupRequestByNumbers);
            return bulkLookupRequestByNumbers;
        }

        public static BulkLookupRequestBySearch getBulkLookupRequestBySearch(){
            BulkLookupRequestBySearch bulkLookupRequestBySearch = new BulkLookupRequestBySearch();
            bulkLookupRequestBySearch.setLookupRequestBySearch(new ArrayList<>());
            LookupRequestBySearch lookupRequestBySearch = new LookupRequestBySearch();
            lookupRequestBySearch.setSearchRequest(new TekSearchRequest());
            lookupRequestBySearch.setAssetType(GL_ACCOUNT_ASSET);
            bulkLookupRequestBySearch.getLookupRequestBySearch().add(lookupRequestBySearch);
            return bulkLookupRequestBySearch;
        }
        public static Map<LookupConsumerAsset, List<LookupEntity>> getResultMap(){
            return Map.ofEntries(Map.entry(GL_ACCOUNT_ASSET, getLookupEntityList()));
        }

        public static Map<LookupConsumerAsset, LookupSearchResponse> getResultMapForLookupBySearch(){
            return Map.ofEntries(Map.entry(GL_ACCOUNT_ASSET, getLookupSearchResponse()));
        }
        public static List<LookupEntity> getLookupEntityList(){
            return List.of(new LookupEntity("test_internal","testing_internal",null));
        }

        public static LookupSearchResponse getLookupSearchResponse(){
            return new LookupSearchResponse(getLookupEntityList(),1);
        }
    }
}