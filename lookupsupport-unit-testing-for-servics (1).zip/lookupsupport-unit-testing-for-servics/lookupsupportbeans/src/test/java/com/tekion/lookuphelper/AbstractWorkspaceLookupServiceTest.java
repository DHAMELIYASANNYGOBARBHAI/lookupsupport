package com.tekion.lookuphelper;

import com.tekion.admin.beans.workspace.Workspace;
import com.tekion.clients.preference.beans.responseEntity.TResponse;
import com.tekion.clients.preference.client.PreferenceClient;
import com.tekion.lookuphelper.dto.request.*;
import com.tekion.lookuphelper.dto.response.LookupEntity;
import com.tekion.lookuphelper.dto.response.LookupSearchResponse;
import com.tekion.lookuphelper.utils.TConstants;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static com.tekion.lookuphelper.WorkspaceLookupAsset.GL_ACCOUNT_ASSET;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AbstractWorkspaceLookupServiceTest {

    @Mock
    PreferenceClient preferenceClient;
    AbstractWorkspaceLookupService abstractWorkspaceLookupService;


    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        abstractWorkspaceLookupService = new ConcreteWorkspaceLookupService(preferenceClient);

    }

    @Test
    public void lookupByIds() {

        WorkspaceLookupRequestByIds workspaceLookupRequestByIds = new WorkspaceLookupRequestByIds();
        List<WorkspaceByIds> workspaceByIds = new ArrayList<>();
        workspaceByIds.add(new WorkspaceByIds("1", List.of("1", "2", "3")));
        workspaceLookupRequestByIds.setAssetType(GL_ACCOUNT_ASSET);
        workspaceLookupRequestByIds.setWorkspaceByIds(workspaceByIds);
        Workspace workspace = new Workspace();
        workspace.setAccessibleDealerIds(List.of("1", "2", "3"));
        TResponse<Workspace> response = new TResponse<>(workspace, "success");
        when(preferenceClient.getWorkspaceByWorkspaceId(isNull())).thenReturn(response);
        Map<String, List<LookupEntity>> result = abstractWorkspaceLookupService.lookupByIds(
                workspaceLookupRequestByIds);
        Assertions.assertEquals(Collections.emptyMap(), result);


    }


    @Test
    public void lookupByNumber() {

        WorkspaceLookupRequestByNumbers workspaceLookupRequestByNumbers = new WorkspaceLookupRequestByNumbers();
        List<WorkspaceByNumbers> workspaceByNumbers = new ArrayList<>();
        workspaceByNumbers.add(new WorkspaceByNumbers("1", List.of("1", "2", "3")));
        workspaceLookupRequestByNumbers.setAssetType(GL_ACCOUNT_ASSET);
        workspaceLookupRequestByNumbers.setWorkspaceByNumbers(workspaceByNumbers);
        Workspace workspace = new Workspace();
        workspace.setAccessibleDealerIds(List.of("1", "2", "3"));
        TResponse<Workspace> response = new TResponse<>(workspace, "success");
        when(preferenceClient.getWorkspaceByWorkspaceId(isNull())).thenReturn(response);
        Map<String, List<LookupEntity>> result = abstractWorkspaceLookupService.lookupByNumber(
                workspaceLookupRequestByNumbers);
        Assertions.assertEquals(Collections.emptyMap(), result);
    }

    @Test
    public void lookupBySearch() {

        WorkspaceLookupRequestBySearch workspaceLookupRequestBySearch = new WorkspaceLookupRequestBySearch();
        workspaceLookupRequestBySearch.setDealerIds(List.of("1", "2", "3"));
        workspaceLookupRequestBySearch.setAssetType(GL_ACCOUNT_ASSET);
        Workspace workspace = new Workspace();
        workspace.setAccessibleDealerIds(List.of("1", "2", "3"));
        TResponse<Workspace> response = new TResponse<>(workspace, "success");
        when(preferenceClient.getWorkspaceByWorkspaceId(isNull())).thenReturn(response);
        LookupSearchResponse result = abstractWorkspaceLookupService.lookupBySearch(workspaceLookupRequestBySearch);
        Assertions.assertEquals(TConstants.EMPTY_SEARCH_RESPONSE, result);
    }


    private static class ConcreteWorkspaceLookupService extends AbstractWorkspaceLookupService {

        public ConcreteWorkspaceLookupService(PreferenceClient preferenceClient) {
            super(preferenceClient);
        }

        @Override
        protected Map<String, List<LookupEntity>> doLookupByIds(
                WorkspaceLookupRequestByIds workspaceLookupRequestByIds) {
            return new HashMap<>();
        }

        @Override
        protected LookupSearchResponse doLookupSearch(WorkspaceLookupRequestBySearch workspaceLookupRequestBySearch) {
            return TConstants.EMPTY_SEARCH_RESPONSE;
        }

        @Override
        protected Map<String, List<LookupEntity>> doLookupByNumber(
                WorkspaceLookupRequestByNumbers workspaceLookupRequestByNumbers) {
            return new HashMap<>();
        }

        @Override
        public List getSupportedLookupAssets() {
            return new ArrayList<>();
        }
    }

}