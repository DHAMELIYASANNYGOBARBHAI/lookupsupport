package com.tekion.lookuphelper;

import com.google.common.collect.Lists;
import com.tekion.clients.preference.client.PreferenceClient;
import com.tekion.core.es.common.impl.TekSearchRequest;
import com.tekion.lookuphelper.dto.request.*;
import com.tekion.lookuphelper.dto.response.LookupEntity;
import com.tekion.lookuphelper.dto.response.LookupSearchResponse;
import com.tekion.lookuphelper.lookupConsumerClient.WorkspaceLookupConsumerServiceClient;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static com.tekion.lookuphelper.WorkspaceLookupAsset.GL_ACCOUNT_ASSET;
import static com.tekion.lookuphelper.WorkspaceMultiLookupServiceV2Test.Utils.*;

@ExtendWith(MockitoExtension.class)
class WorkspaceMultiLookupServiceV2Test {
    @InjectMocks
    WorkspaceMultiLookupServiceV2 workspaceMultiLookupServiceV2;
    @Mock
    WorkspaceLookupServiceProvider workspaceLookupServiceProvider;
    @Mock
    WorkspaceLookupConsumerServiceClient workspaceLookupConsumerServiceClient;
    @Mock
    PreferenceClient preferenceClient;

    @Test
    public void lookupByIds_WhenLookUpServiceIsNotNull(){
        BulkWorkspaceLookupRequestByIds bulkWorkspaceLookupRequestByIds = getBulkWorkSpaceLookupRequestByIds();
        Map<WorkspaceLookupAsset, Map<String, List<LookupEntity>>> expectedResultMap = getResultMap();

        Mockito.when(workspaceLookupServiceProvider.getServiceForLookupAsset(GL_ACCOUNT_ASSET)).thenReturn(new DummyAbstractWorkSpaceLookupService(preferenceClient));

        Map<IWorkspaceLookupAsset, Map<String, List<LookupEntity>>> actualResultMap =
                workspaceMultiLookupServiceV2.doLookupByIds(bulkWorkspaceLookupRequestByIds);

        Assertions.assertEquals(expectedResultMap, actualResultMap);

    }

    @Test
    public void lookupByIds_WhenLookUpServiceIsNull(){
        BulkWorkspaceLookupRequestByIds bulkWorkspaceLookupRequestByIds = getBulkWorkSpaceLookupRequestByIds();
        Map<WorkspaceLookupAsset, Map<String, List<LookupEntity>>> expectedResultMap = getResultMap();

        Mockito.when(workspaceLookupServiceProvider.getServiceForLookupAsset(GL_ACCOUNT_ASSET)).thenReturn(null);
        Mockito.when(workspaceLookupConsumerServiceClient.workspaceLookupByIds(Mockito.any())).thenReturn(getResultMap());

        Map<IWorkspaceLookupAsset, Map<String, List<LookupEntity>>> actualResultMap =
                workspaceMultiLookupServiceV2.doLookupByIds(bulkWorkspaceLookupRequestByIds);

        Assertions.assertEquals(expectedResultMap, actualResultMap);
    }

    @Test
    public void lookupByNumbers_WhenLookUpServiceIsNotNull(){
        BulkWorkspaceLookupRequestByNumbers bulkWorkspaceLookupRequestByNumbers = getBulkWorkSpaceLookupRequestByNumbers();
        Map<WorkspaceLookupAsset, Map<String, List<LookupEntity>>> expectedResultMap = getResultMap();

        Mockito.when(workspaceLookupServiceProvider.getServiceForLookupAsset(GL_ACCOUNT_ASSET)).thenReturn(new DummyAbstractWorkSpaceLookupService(preferenceClient));

        Map<IWorkspaceLookupAsset, Map<String, List<LookupEntity>>> actualResultMap =
                workspaceMultiLookupServiceV2.doLookupByNumber(bulkWorkspaceLookupRequestByNumbers);

        Assertions.assertEquals(expectedResultMap, actualResultMap);

    }

    @Test
    public void lookupByNumbers_WhenLookUpServiceIsNull(){
        BulkWorkspaceLookupRequestByNumbers bulkWorkspaceLookupRequestByNumbers = getBulkWorkSpaceLookupRequestByNumbers();
        Map<WorkspaceLookupAsset, Map<String, List<LookupEntity>>> expectedResultMap = getResultMap();

        Mockito.when(workspaceLookupServiceProvider.getServiceForLookupAsset(GL_ACCOUNT_ASSET)).thenReturn(null);
        Mockito.when(workspaceLookupConsumerServiceClient.workspaceLookupByNumbers(Mockito.any())).thenReturn(getResultMap());

        Map<IWorkspaceLookupAsset, Map<String, List<LookupEntity>>> actualResultMap =
                workspaceMultiLookupServiceV2.doLookupByNumber(bulkWorkspaceLookupRequestByNumbers);

        Assertions.assertEquals(expectedResultMap, actualResultMap);

    }

    @Test
    public void lookupBySearch_WhenLookUpServiceIsNotNull(){
        BulkWorkspaceLookupRequestBySearch bulkWorkspaceLookupRequestBySearch = getBulkWorkSpaceLookupRequestBySearch();
        Map<? extends ILookupAsset, LookupSearchResponse> expectedResultMap = getResultMapForLookupBySearch();

        Mockito.when(workspaceLookupServiceProvider.getServiceForLookupAsset(GL_ACCOUNT_ASSET)).thenReturn(new DummyAbstractWorkSpaceLookupService(preferenceClient));

        Map<? extends ILookupAsset, LookupSearchResponse> actualResultMap =
                workspaceMultiLookupServiceV2.doLookupSearch(bulkWorkspaceLookupRequestBySearch);

        Assertions.assertEquals(expectedResultMap, actualResultMap);

    }

    @Test
    public void lookupBySearch_WhenLookUpServiceIsNull() {
        BulkWorkspaceLookupRequestBySearch bulkWorkspaceLookupRequestBySearch = getBulkWorkSpaceLookupRequestBySearch();
        Map<? extends ILookupAsset, LookupSearchResponse> expectedResultMap = getResultMapForLookupBySearch();

        Mockito.when(workspaceLookupServiceProvider.getServiceForLookupAsset(GL_ACCOUNT_ASSET)).thenReturn(null);
        Mockito.when(workspaceLookupConsumerServiceClient.workspaceLookupBySearch(Mockito.any())).thenReturn(getResultMapForLookupBySearch());

        Map<? extends ILookupAsset, LookupSearchResponse> actualResultMap = workspaceMultiLookupServiceV2.doLookupSearch(
                bulkWorkspaceLookupRequestBySearch);

        Assertions.assertEquals(expectedResultMap, actualResultMap);

    }
    private static class DummyAbstractWorkSpaceLookupService extends AbstractWorkspaceLookupService {

        public DummyAbstractWorkSpaceLookupService(PreferenceClient preferenceClient) {
            super(preferenceClient);
        }

        @Override
        public Map<String, List<LookupEntity>> lookupByIds(WorkspaceLookupRequestByIds workspaceLookupRequestByIds) {
            return getDealerWiseResultMap();
        }

        @Override
        public Map<String, List<LookupEntity>> lookupByNumber(
                WorkspaceLookupRequestByNumbers workspaceLookupRequestByNumbers) {
            return getDealerWiseResultMap();
        }

        @Override
        public LookupSearchResponse lookupBySearch(WorkspaceLookupRequestBySearch workspaceLookupRequestBySearch) {
            return getLookupSearchResponse();
        }

        @Override
        public List<ILookupAsset> getSupportedLookupAssets() {
            return Lists.newArrayList(GL_ACCOUNT_ASSET);
        }

        @Override
        protected Map<String, List<LookupEntity>> doLookupByIds(
                WorkspaceLookupRequestByIds workspaceLookupRequestByIds) {
            return null;
        }

        @Override
        protected LookupSearchResponse doLookupSearch(WorkspaceLookupRequestBySearch workspaceLookupRequestBySearch) {
            return null;
        }

        @Override
        protected Map<String, List<LookupEntity>> doLookupByNumber(
                WorkspaceLookupRequestByNumbers workspaceLookupRequestByNumbers) {
            return null;
        }
    }

    public static class Utils{
        public static BulkWorkspaceLookupRequestByIds getBulkWorkSpaceLookupRequestByIds(){
            BulkWorkspaceLookupRequestByIds bulkWorkspaceLookupRequestByIds = new BulkWorkspaceLookupRequestByIds();
            bulkWorkspaceLookupRequestByIds.setWorkspaceLookupRequestByIds(new ArrayList<>());
            WorkspaceLookupRequestByIds workspaceLookupRequestByIds = new WorkspaceLookupRequestByIds();
            workspaceLookupRequestByIds.setWorkspaceByIds(Collections.emptyList());
            workspaceLookupRequestByIds.setAssetType(GL_ACCOUNT_ASSET);
            workspaceLookupRequestByIds.setIncludeFields(Collections.emptyList());
            workspaceLookupRequestByIds.setExcludeFields(Collections.emptyList());
            bulkWorkspaceLookupRequestByIds.getWorkspaceLookupRequestByIds().add(workspaceLookupRequestByIds);
            return bulkWorkspaceLookupRequestByIds;
        }

        public static BulkWorkspaceLookupRequestByNumbers getBulkWorkSpaceLookupRequestByNumbers(){
            BulkWorkspaceLookupRequestByNumbers bulkWorkspaceLookupRequestByNumbers = new BulkWorkspaceLookupRequestByNumbers();
            bulkWorkspaceLookupRequestByNumbers.setWorkspaceLookupRequestByNumbers(new ArrayList<>());
            WorkspaceLookupRequestByNumbers workspaceLookupRequestByNumbers = new WorkspaceLookupRequestByNumbers();
            workspaceLookupRequestByNumbers.setWorkspaceByNumbers(Collections.emptyList());
            workspaceLookupRequestByNumbers.setAssetType(GL_ACCOUNT_ASSET);
            workspaceLookupRequestByNumbers.setIncludeFields(Collections.emptyList());
            workspaceLookupRequestByNumbers.setExcludeFields(Collections.emptyList());
            bulkWorkspaceLookupRequestByNumbers.getWorkspaceLookupRequestByNumbers().add(workspaceLookupRequestByNumbers);
            return bulkWorkspaceLookupRequestByNumbers;
        }

        public static BulkWorkspaceLookupRequestBySearch getBulkWorkSpaceLookupRequestBySearch(){
            BulkWorkspaceLookupRequestBySearch bulkWorkspaceLookupRequestBySearch = new BulkWorkspaceLookupRequestBySearch();
            bulkWorkspaceLookupRequestBySearch.setWorkspaceLookupRequestBySearch(new ArrayList<>());
            WorkspaceLookupRequestBySearch workspaceLookupRequestBySearch = new WorkspaceLookupRequestBySearch();
            workspaceLookupRequestBySearch.setSearchRequest(new TekSearchRequest());
            workspaceLookupRequestBySearch.setAssetType(GL_ACCOUNT_ASSET);
            bulkWorkspaceLookupRequestBySearch.getWorkspaceLookupRequestBySearch().add(workspaceLookupRequestBySearch);
            return bulkWorkspaceLookupRequestBySearch;
        }
        public static Map<WorkspaceLookupAsset, Map<String,List<LookupEntity>>> getResultMap(){
            return Map.ofEntries(Map.entry(GL_ACCOUNT_ASSET, getDealerWiseResultMap()));
        }

        public static Map<String,List<LookupEntity>> getDealerWiseResultMap(){
            return  Map.ofEntries(Map.entry("sample_dealer", getLookupEntityList()));
        }

        public static Map<WorkspaceLookupAsset, LookupSearchResponse> getResultMapForLookupBySearch(){
            return Map.ofEntries(Map.entry(GL_ACCOUNT_ASSET, getLookupSearchResponse()));
        }
        public static List<LookupEntity> getLookupEntityList(){
            return List.of(new LookupEntity("test_internal","testing_internal",null));
        }

        public static LookupSearchResponse getLookupSearchResponse(){
            return new LookupSearchResponse(getLookupEntityList(),1);
        }
    }
}