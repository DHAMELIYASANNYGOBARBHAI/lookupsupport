package com.tekion.lookuphelper;

import com.google.common.collect.Lists;
import com.tekion.lookuphelper.dto.request.BulkLookupRequestByIds;
import com.tekion.lookuphelper.dto.request.BulkLookupRequestByNumbers;
import com.tekion.lookuphelper.dto.request.BulkLookupRequestBySearch;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.tekion.lookuphelper.LookupConsumerAsset.GL_ACCOUNT_ASSET;
import static com.tekion.tekionconstant.lookupconsumer.LookupAsset.CUSTOMER;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class LookupServiceProviderTest {
    DummyAbstractLookupService dummyAbstractLookupService;
    LookupServiceProvider lookupServiceProvider;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        dummyAbstractLookupService = new DummyAbstractLookupService();
        lookupServiceProvider = new LookupServiceProvider(Lists.newArrayList(dummyAbstractLookupService));
    }

    @Test
    void getServiceForLookupAsset() {
        AbstractLookupService abstractLookupService = lookupServiceProvider.getServiceForLookupAsset(GL_ACCOUNT_ASSET);
        Assertions.assertEquals(abstractLookupService.getClass(), DummyAbstractLookupService.class);
    }

    private static class DummyAbstractLookupService extends AbstractLookupService {

        @Override
        protected Map doLookupByIds(BulkLookupRequestByIds bulkLookupRequestByIds) {
            return new HashMap<>();
        }

        @Override
        protected Map doLookupBySearch(BulkLookupRequestBySearch bulkLookupRequestBySearch) {
            return new HashMap<>();
        }

        @Override
        protected Map doLookupByNumber(BulkLookupRequestByNumbers bulkLookupRequestByNumbers) {
            return new HashMap<>();
        }

        @Override
        public List<ILookupAsset> getSupportedLookupAssets() {
            return Lists.newArrayList(GL_ACCOUNT_ASSET);
        }
    }
}