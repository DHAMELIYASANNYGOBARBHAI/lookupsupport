package com.tekion.lookuphelper;

import com.google.common.collect.Lists;
import com.tekion.clients.preference.client.PreferenceClient;
import com.tekion.lookuphelper.dto.request.*;
import com.tekion.lookuphelper.dto.response.LookupEntity;
import com.tekion.lookuphelper.dto.response.LookupSearchResponse;
import com.tekion.lookuphelper.utils.TConstants;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ExtendWith(MockitoExtension.class)
class WorkspaceLookupServiceProviderTest{
    DummyAbstractWorkspaceLookupService dummyAbstractWorkspaceLookupService;
    WorkspaceLookupServiceProvider workspaceLookupServiceProvider;
    @Mock
    PreferenceClient preferenceClient;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        dummyAbstractWorkspaceLookupService = new DummyAbstractWorkspaceLookupService(preferenceClient);
        workspaceLookupServiceProvider = new WorkspaceLookupServiceProvider(Lists.newArrayList(dummyAbstractWorkspaceLookupService));
    }

    @Test
    void getServiceForLookupAsset() {
        AbstractWorkspaceLookupService abstractWorkspaceLookupService =
                workspaceLookupServiceProvider.getServiceForLookupAsset(WorkspaceLookupAsset.GL_ACCOUNT_ASSET);
        Assertions.assertEquals(abstractWorkspaceLookupService.getClass(), DummyAbstractWorkspaceLookupService.class);
    }

    private static class DummyAbstractWorkspaceLookupService extends AbstractWorkspaceLookupService {
        public DummyAbstractWorkspaceLookupService(PreferenceClient preferenceClient) {
            super(preferenceClient);
        }

        @Override
        protected Map<String, List<LookupEntity>> doLookupByIds(
                WorkspaceLookupRequestByIds workspaceLookupRequestByIds) {
            return new HashMap<>();
        }

        @Override
        protected LookupSearchResponse doLookupSearch(WorkspaceLookupRequestBySearch workspaceLookupRequestBySearch) {
            return TConstants.EMPTY_SEARCH_RESPONSE;
        }

        @Override
        protected Map<String, List<LookupEntity>> doLookupByNumber(
                WorkspaceLookupRequestByNumbers workspaceLookupRequestByNumbers) {
            return new HashMap<>();
        }

        @Override
        public List getSupportedLookupAssets() {
            return Lists.newArrayList(WorkspaceLookupAsset.GL_ACCOUNT_ASSET);
        }
    }
}