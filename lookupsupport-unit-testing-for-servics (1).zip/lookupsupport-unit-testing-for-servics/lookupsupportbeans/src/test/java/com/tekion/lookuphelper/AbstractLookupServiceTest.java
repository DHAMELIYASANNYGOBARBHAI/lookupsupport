package com.tekion.lookuphelper;


import com.tekion.lookuphelper.dto.request.*;
import com.tekion.lookuphelper.dto.response.LookupEntity;
import com.tekion.lookuphelper.dto.response.LookupSearchResponse;
import com.tekion.lookuphelper.utils.TConstants;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static com.tekion.lookuphelper.LookupConsumerAsset.CUSTOMER;

@ExtendWith(MockitoExtension.class)
class AbstractLookupServiceTest {


    @InjectMocks
    AbstractLookupService abstractLookupService = new AbstractLookupService() {

        @Override
        protected Map doLookupByIds(BulkLookupRequestByIds bulkLookupRequestByIds) {
            return new HashMap();
        }

        @Override
        protected Map doLookupBySearch(BulkLookupRequestBySearch bulkLookupRequestBySearch) {
            return new HashMap();
        }

        @Override
        protected Map doLookupByNumber(BulkLookupRequestByNumbers bulkLookupRequestByNumbers) {
            return new HashMap();
        }

        @Override
        public List<ILookupAsset> getSupportedLookupAssets() {
            return new ArrayList<>();
        }
    };

    @Test
    void lookupByIds() {
        LookupRequestByIds lookupRequestByIds = new LookupRequestByIds();
        lookupRequestByIds.setAssetType(CUSTOMER);
        List<LookupEntity> result = abstractLookupService.lookupByIds(lookupRequestByIds);
        Assertions.assertEquals(Collections.emptyList(), result);
    }

    @Test
    void bulkLookupByIds() {
        BulkLookupRequestByIds bulkLookupRequestByIds = new BulkLookupRequestByIds();
        Map<ILookupAsset, List<LookupEntity>> result = abstractLookupService.bulkLookupByIds(bulkLookupRequestByIds);
        Assertions.assertEquals(Collections.emptyMap(), result);
    }

    @Test
    void lookupBySearch() {
        LookupRequestBySearch lookupRequestBySearch = new LookupRequestBySearch();
        lookupRequestBySearch.setAssetType(CUSTOMER);
        LookupSearchResponse lookupSearchResponse = abstractLookupService.lookupBySearch(lookupRequestBySearch);
        Assertions.assertEquals(TConstants.EMPTY_SEARCH_RESPONSE, lookupSearchResponse);
    }

    @Test
    void bulkLookupBySearch() {
        BulkLookupRequestBySearch bulkLookupRequestBySearch = new BulkLookupRequestBySearch();
        Map<ILookupAsset, LookupSearchResponse> result = abstractLookupService.bulkLookupBySearch(
                bulkLookupRequestBySearch);
        Assertions.assertEquals(Collections.emptyMap(), result);
    }

    @Test
    void lookupByNumber() {
        LookupRequestByNumbers lookupRequestByNumbers = new LookupRequestByNumbers();
        lookupRequestByNumbers.setAssetType(CUSTOMER);
        List<LookupEntity> result = abstractLookupService.lookupByNumber(lookupRequestByNumbers);
        Assertions.assertEquals(Collections.emptyList(), result);
    }

    @Test
    void bulkLookupByNumber() {
        BulkLookupRequestByNumbers bulkLookupRequestByNumbers = new BulkLookupRequestByNumbers();
        Map<ILookupAsset, List<LookupEntity>> result = abstractLookupService.bulkLookupByNumber(
                bulkLookupRequestByNumbers);
        Assertions.assertEquals(Collections.emptyMap(), result);
    }
}