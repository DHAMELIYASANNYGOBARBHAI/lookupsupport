package com.tekion.lookuphelper;

public interface IWorkspaceLookupAsset extends ILookupAsset {


}
