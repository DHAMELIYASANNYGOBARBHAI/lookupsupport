package com.tekion.lookuphelper;

import com.tekion.lookuphelper.dto.request.*;
import com.tekion.lookuphelper.dto.response.LookupEntity;
import com.tekion.lookuphelper.dto.response.LookupSearchResponse;
import com.tekion.lookuphelper.lookupConsumerClient.LookupServiceClient;
import com.tekion.lookuphelper.utils.TConstants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static org.apache.commons.collections4.MapUtils.emptyIfNull;
import static org.apache.commons.collections4.ListUtils.emptyIfNull;

@Slf4j
@Service
@RequiredArgsConstructor
public class MultiLookupServiceV2 {

    private final LookupServiceProvider lookupServiceProvider;
    private final LookupServiceClient lookupServiceClient;

    public Map<ILookupAsset, List<LookupEntity>> lookupByIds(BulkLookupRequestByIds bulkLookupRequestByIds) {

        log.info(bulkLookupRequestByIds.toString());

        Map<ILookupAsset, List<LookupEntity>> resultMap = new HashMap<>();
        Map<String, BulkLookupRequestByIds> forwardAppRootVsLookupRequestMap = new HashMap<>();

        for (LookupRequestByIds lookupRequestByIds : emptyIfNull(bulkLookupRequestByIds.getLookupRequestByIds())) {
            LookupService lookupService = lookupServiceProvider.getServiceForLookupAsset(
                    lookupRequestByIds.getAssetType());

            if (Objects.nonNull(lookupService)) {
                List<LookupEntity> assetLookupList = Collections.emptyList();
                try {
                    assetLookupList = lookupService.lookupByIds(lookupRequestByIds);
                } catch (Exception exception) {
                    log.error("Lookup failed for asset {}", lookupRequestByIds.getAssetType(), exception);
                }
                resultMap.put(lookupRequestByIds.getAssetType(), assetLookupList);
            } else {
                String forwardAppRoot = lookupRequestByIds.getAssetType().getForwardAppRoot();
                forwardAppRootVsLookupRequestMap
                        .computeIfAbsent(forwardAppRoot, key -> new BulkLookupRequestByIds(new ArrayList<>()))
                        .getLookupRequestByIds().add(lookupRequestByIds);
            }
        }
        resultMap.putAll(emptyIfNull(lookupByIdsToExternalServices(forwardAppRootVsLookupRequestMap)));
        return resultMap;
    }

    private Map<ILookupAsset, List<LookupEntity>> lookupByIdsToExternalServices(
            Map<String, BulkLookupRequestByIds> forwardAppRootVsLookupRequestMap) {
        Map<ILookupAsset, List<LookupEntity>> resultMap = new HashMap<>();
        for (Map.Entry<String, BulkLookupRequestByIds> entryForEachForwardAppRoot : emptyIfNull(
                forwardAppRootVsLookupRequestMap).entrySet()) {
            String forwardAppRoot = entryForEachForwardAppRoot.getKey();
            BulkLookupRequestByIds bulkLookupRequestByIds = entryForEachForwardAppRoot.getValue();
            try {
                resultMap.putAll(emptyIfNull(lookupServiceClient.lookupByIds(bulkLookupRequestByIds)));
            } catch (Exception exception) {
                log.error("Lookup failed for assets {} for forward app root {}",
                        bulkLookupRequestByIds.getLookupRequestByIds().stream().map(LookupRequestByIds::getAssetType)
                                              .collect(Collectors.toList()), forwardAppRoot);
            }
        }
        return resultMap;
    }

    public Map<ILookupAsset, LookupSearchResponse> lookupBySearch(BulkLookupRequestBySearch bulkLookupRequestBySearch) {

        Map<ILookupAsset, LookupSearchResponse> resultMap = new HashMap<>();
        Map<String, BulkLookupRequestBySearch> forwardAppRootVsLookupRequestMap = new HashMap<>();

        for (LookupRequestBySearch lookupRequestBySearch : emptyIfNull(
                bulkLookupRequestBySearch.getLookupRequestBySearch())) {
            LookupService lookupService = lookupServiceProvider.getServiceForLookupAsset(
                    lookupRequestBySearch.getAssetType());

            if (Objects.nonNull(lookupService)) {
                LookupSearchResponse assetSearchResponse = TConstants.EMPTY_SEARCH_RESPONSE;
                try {
                    assetSearchResponse = lookupService.lookupBySearch(lookupRequestBySearch);
                } catch (Exception exception) {
                    log.error("Lookup failed for asset {}", lookupRequestBySearch.getAssetType(), exception);
                }
                resultMap.put(lookupRequestBySearch.getAssetType(), assetSearchResponse);
            } else {
                String forwardAppRoot = lookupRequestBySearch.getAssetType().getForwardAppRoot();
                forwardAppRootVsLookupRequestMap
                        .computeIfAbsent(forwardAppRoot, key -> new BulkLookupRequestBySearch(new ArrayList<>()))
                        .getLookupRequestBySearch().add(lookupRequestBySearch);
            }
        }
        resultMap.putAll(emptyIfNull(lookupBySearchToExternalServices(forwardAppRootVsLookupRequestMap)));
        return resultMap;
    }

    private Map<ILookupAsset, LookupSearchResponse> lookupBySearchToExternalServices(
            Map<String, BulkLookupRequestBySearch> forwardAppRootVsLookupRequestMap) {
        Map<ILookupAsset, LookupSearchResponse> resultMap = new HashMap<>();
        for (Map.Entry<String, BulkLookupRequestBySearch> entryForEachForwardAppRoot : emptyIfNull(
                forwardAppRootVsLookupRequestMap).entrySet()) {
            String forwardAppRoot = entryForEachForwardAppRoot.getKey();
            BulkLookupRequestBySearch bulkLookupRequestBySearch = entryForEachForwardAppRoot.getValue();
            try {
                resultMap.putAll(emptyIfNull(lookupServiceClient.lookupBySearch(bulkLookupRequestBySearch)));
            } catch (Exception exception) {
                log.error("Lookup failed for assets {} for forward app root {}",
                        bulkLookupRequestBySearch.getLookupRequestBySearch().stream()
                                                 .map(LookupRequestBySearch::getAssetType).collect(Collectors.toList()),
                        forwardAppRoot);
            }
        }
        return resultMap;
    }

    public Map<ILookupAsset, List<LookupEntity>> lookupByNumber(BulkLookupRequestByNumbers bulkLookupRequestByNumbers) {

        Map<ILookupAsset, List<LookupEntity>> resultMap = new HashMap<>();
        Map<String, BulkLookupRequestByNumbers> forwardAppRootVsLookupRequestMap = new HashMap<>();

        for (LookupRequestByNumbers lookupRequestByNumbers : emptyIfNull(
                bulkLookupRequestByNumbers.getLookupRequestByNumbers())) {
            LookupService lookupService = lookupServiceProvider.getServiceForLookupAsset(
                    lookupRequestByNumbers.getAssetType());

            if (Objects.nonNull(lookupService)) {
                List<LookupEntity> assetLookupList = Collections.emptyList();
                try {
                    assetLookupList = lookupService.lookupByNumber(lookupRequestByNumbers);
                } catch (Exception exception) {
                    log.error("Lookup failed for asset {}", lookupRequestByNumbers.getAssetType(), exception);
                }
                resultMap.put(lookupRequestByNumbers.getAssetType(), assetLookupList);
            } else {
                String forwardAppRoot = lookupRequestByNumbers.getAssetType().getForwardAppRoot();
                forwardAppRootVsLookupRequestMap
                        .computeIfAbsent(forwardAppRoot, key -> new BulkLookupRequestByNumbers(new ArrayList<>()))
                        .getLookupRequestByNumbers().add(lookupRequestByNumbers);
            }
        }
        resultMap.putAll(emptyIfNull(lookupByNumberToExternalServices(forwardAppRootVsLookupRequestMap)));
        return resultMap;
    }

    private Map<ILookupAsset, List<LookupEntity>> lookupByNumberToExternalServices(
            Map<String, BulkLookupRequestByNumbers> forwardAppRootVsLookupRequestMap) {
        Map<ILookupAsset, List<LookupEntity>> resultMap = new HashMap<>();
        for (Map.Entry<String, BulkLookupRequestByNumbers> entryForEachForwardAppRoot : emptyIfNull(
                forwardAppRootVsLookupRequestMap).entrySet()) {
            String forwardAppRoot = entryForEachForwardAppRoot.getKey();
            BulkLookupRequestByNumbers bulkLookupRequestByNumbers = entryForEachForwardAppRoot.getValue();
            try {
                resultMap.putAll(emptyIfNull(lookupServiceClient.lookupByNumbers(bulkLookupRequestByNumbers)));
            } catch (Exception exception) {
                log.error("Lookup failed for assets {} for forward app root {}",
                        bulkLookupRequestByNumbers.getLookupRequestByNumbers().stream()
                                                  .map(LookupRequestByNumbers::getAssetType)
                                                  .collect(Collectors.toList()), forwardAppRoot);
            }
        }
        return resultMap;
    }

}
