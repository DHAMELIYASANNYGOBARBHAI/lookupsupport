package com.tekion.lookuphelper.api;

import com.tekion.core.service.api.TResponseEntityBuilder;
import com.tekion.core.validation.TValidator;
import com.tekion.lookuphelper.MultiLookupServiceV2;
import com.tekion.lookuphelper.dto.request.BulkLookupRequestByIds;
import com.tekion.lookuphelper.dto.request.BulkLookupRequestByNumbers;
import com.tekion.lookuphelper.dto.request.BulkLookupRequestBySearch;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping(value = "/lookup/v2")
public class LookupControllerV2 {

    private final MultiLookupServiceV2 lookupService;
    private final TValidator tValidator;

    @PostMapping("/ids")
    public ResponseEntity bulkLookupAssetById(@RequestBody BulkLookupRequestByIds bulkLookupRequestByIds) {
        tValidator.validate(bulkLookupRequestByIds);
        return TResponseEntityBuilder.okResponseEntity(lookupService.lookupByIds(bulkLookupRequestByIds));
    }

    @PostMapping("/numbers")
    public ResponseEntity bulkLookupAssetByNumber(@RequestBody BulkLookupRequestByNumbers bulkLookupRequestByNumbers) {
        tValidator.validate(bulkLookupRequestByNumbers);
        return TResponseEntityBuilder.okResponseEntity(lookupService.lookupByNumber(bulkLookupRequestByNumbers));
    }

    @PostMapping("/search")
    public ResponseEntity bulkLookupAssetBySearch(@RequestBody BulkLookupRequestBySearch bulkLookupRequestBySearch) {
        tValidator.validate(bulkLookupRequestBySearch);
        return TResponseEntityBuilder.okResponseEntity(lookupService.lookupBySearch(bulkLookupRequestBySearch));
    }
}
