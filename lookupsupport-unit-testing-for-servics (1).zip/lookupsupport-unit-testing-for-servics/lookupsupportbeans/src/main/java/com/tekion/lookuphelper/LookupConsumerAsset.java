package com.tekion.lookuphelper;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import javax.validation.constraints.NotNull;


@Getter
@RequiredArgsConstructor
public enum LookupConsumerAsset implements ILookupAsset {

    CUSTOMER(true, true, "cms", true),
    FEE(true, true, "fee"),
    TICKET(true, true, "warranty"),
    VENDOR(true, true, "vms", true),
    PARTMASTER(true, true, "wms"),
    DELAERPART(true, true, "wms"),
    PARTINVENTORY(true, true, "wms"),
    PARTSALES(true, true, "partTrade", true),
    PART_INVOICE(true, true, "partTrade", true),
    PARTPO(true, true, "partTrade", true),
    PART(true, true, "wms"),
    BINS(true, true, "wms"),
    PARTSOURCECODE(true, true, "wms"),
    PARTCUSTPRICE(true, true, "wms"),
    PARTPRICECODE(true, true, "wms"),
    PARTANDINVENTORY(true, true, "wms"),
    REPAIR_ORDER_ASSET(true, true, "ro", true),
    OPCODE(true, true, "opcode"),
    SERVICE_TYPE(false, true, "opcode"),
    DEALS_BY_DEALNUMBER(true, true, "sales/core", true, "DEALSERVICE"),
    VEHICLES_BY_ID(true, true, "vi", true),
    VEHICLES_BY_VIN(true, true, "vi"),
    DSE_USER(false, true, "dse"),
    GL_ACCOUNT_ASSET(true, true, "accounting"),
    VEHICLE_BY_VIN("dse"),
    DEALER_USER(true, true, "dse"),
    DSE_CUSTOMER(false, true, "dse"),
    DSE_DEALER(false, true, "dse"),
    COUPON(true, true, "coupon"),
    GMLABOROPCODE(true, true, "vps","VEHICLEPROFILESERVICE"),
    SALES_ORDER(true, true, "partTrade"),
    PO_INVOICE_ASSET(true, true, "accounting", true),
    STOCK(false, false, "vi", true),
    DEALS_BY_VEHICLEID(true, true, "sales/core", true, "DEALSERVICE"),
    USER(true, true, "settings", true),
    CUSTOMER_MINIMAL_SEARCH(true, true, "cms", false),
    TENANT_USER_MINIMAL(true, true, "settings", false),
    DEALER_ACCESSIBLE_USER_MINIMAL(true, true, "settings", false),
    VEHICLES_BY_LAST_8_VIN(true, true, "vi", true),
    VEHICLE_INTERIOR_COLOR(true, true, "vi", false),
    ANALYTICS_VI(true, false, "analytics", "ANALYTICS"),
    ANALYTICS_DEAL(true, false, "analytics", "ANALYTICS"),
    VEHICLE_EXTERIOR_COLOR(true, true, "vi", false),
    JOURNAL_ASSET(false,true,"accounting",false),
    CAUSE_CODE(false, false, "vps", false),
    LEAD_BY_ID(true, true, "crmlead", false, "CRMLEADSERVICE"),
    DEALER_ACCESSIBLE_USER_MINIMALV3(true, true, "userservice", false, "USERSERVICE"),
    VEHICLE_MODEL_NUMBER(true,false,"vi",false),
    EXPENSE_CODE(false,false,"vps",false),
    VEHICLE_EXTERIOR_COLOR_HEXCODE(true,true,"vi",false),
    NATURE_CODE(false,false,"vps",false),
    DEAL_TAX_COUNTY(true,false,"sales/core",false,"DEALSERVICE"),
    EMPLOYEE(true,true,"userservice",true,"USERSERVICE"),
    VEHICLES_ID_BY_LAST_8_VIN(true,true,"vi",true),
    FEEV2(true,true,"fee",false),
    TAGS_BY_SEARCH(true,true,"crmtask",false,"CRMTASK"),
    DEAL_TAX_STATE(true,false,"sales/core",false,"DEALSERVICE"),
    DRAWERS(true,true,"wms",false),
    SOURCECODE(true,true,"wms",false),
    VEHICLE_CUSTOM_FIELD(true,true,"vi",false),
    ACCOUNTS_COST_CENTER(false,false,"settings",false),
    TAG_BY_NAME(true,true,"crmtask",true,"CRMTASK"),
    LEAD_BY_NAME(true,false,"crmlead",false,"CRMLEADSERVICE"),
    COST_CENTER(true,false,"settings",false),
    SHELVES(true,true,"wms",false),
    DEAL_TAX_CITY(true,false,"sales/core",false),
    DEALER_ACCESSIBLE_USER_MINIMALV2(true,true,"settings",false),
    CAMPAIGN(true,true,"campaignservice",false,"CAMPAIGN_SERVICE"),
    PARTINVENTORYWITHMASTER(true,false,"wms",false),
    WARRANTY_CLAIM_ASSET(true,true,"service-warranty-service",false),
    DEAL_CUSTOMER_STATE(true,false,"sales/core",false,"DEALSERVICE"),
    DEAL_CUSTOMER_CITY(true,false,"sales/core",false,"DEALSERVICE"),
    DEAL_CUSTOMER_COUNTY(true,false,"sales/core",false,"DEALSERVICE"),
    FRANCHISE_ASSET(true,false,"/accounting",true,"ACCOUNTINGSERVICE"),
    COST_ADJUSTMENT(true,true,"sales/settings",false,"SALESSETTINGS"),
    DUE_BILLS (true,true,"sales/settings",false,"SALESSETTINGS"),
    COST_ADJUSTMENT_1(true,true,"sales/settings",false,"SALESSETTINGSSERVICE"),
    COST_ADJUSTMENT_2(true,true,"sales/settings",false,"SALESSETTINGS"),
    COST_ADJUSTMENT_3(true,true,"sales/settings",false,"SALESSETTINGSSERVICE"),
    COST_ADJUSTMENT_6(true,true,"sales/settings/preference",false,"salessettingsservice"),
    DUE_BILL_SETUP(true,true,"sales/settings/preference",false,"salessettingsservice"),
    COST_ADJUSTMENT_SETUP(true,true,"sales/settings/preference",false,"salessettingsservice"),
    LENDERS(true,true,"sales/settings/preference",false,"salessettingsservice"),
    ROLE(true,true,"sales/settings/preference",false,"salessettingsservice"),
    VENDORS(true,true,"sales/settings/preference",false,"salessettingsservice"),
    FNI(true,true,"sales/settings/preference",false,"salessettingsservice"),
    COREPARTINVENTORY(true,true,"wms",false,"WMSSERVICE"),
    COREPARTINVENTORYWITHMASTER(true,true,"wms",false,"WMSSERVICE"),
    ASSIGNEE_USER_BY_PERSONA(true,true,"userservice",false,"USERSERVICE"),
    CRM_SETUP_SALES_LEAD_STAGE(true,false,"crmsetup",false,"CRMSETUP"),
    CRM_SETUP_SERVICE_LEAD_STAGE(true,false,"crmsetup",false,"CRMSETUP"),
    CRM_SETUP_PARTS_LEAD_STAGE(true,false,"crmsetup",false,"CRMSETUP"),
    CRM_SETUP_LEAD_CUSTOM_STAGE (true,false,"crmsetup",false,"CRMSETUP"),
    CRM_SETUP_LEAD_SOURCES(true,false,"crmsetup",false,"CRMSETUP"),
    VEHICLE_MAKES(true,false,"vi",false,"VEHICLEINVENTORYSERVICE"),
    TENANT_USER_MINIMALV2(true,true,"userservice",false,"USERSERVICE"),
    TEAMS_AND_ASSIGNEE_USER_BY_PERSONA(true,true,"userservice",false,"USERSERVICE"),
    CRM_SETUP_LEAD_SOURCE_GROUP(true,true,"crmsetup",false,"CRMSETUP"),
    VEHICLE_PROVIDER_ORDER_STAUS(true,false,"vi",false,"VEHICLEINVENTORYSERVICE"),
    VEHICLE_PROVIDER_ORDER_STATUS(true,false,"vi",false,"VEHICLEINVENTORYSERVICE"),
    TESTINGWARRANTY(false,false,"/vps",false,"VEHICLEPROFILESERVICE");


    private final boolean searchSupported;
    private final boolean idSupported;
    @NotNull
    private final String forwardAppRoot;
    private final boolean numberSupported;
    @NotNull
    private final String serviceName;
    public static final String DEFAULT_HOST_SERVICE = "CONFIG_HOST_SERVICE";

    LookupConsumerAsset(

            boolean searchSupported, boolean idSupported, String forwardAppRoot, String serviceName) {

        this.searchSupported = searchSupported;
        this.idSupported = idSupported;
        this.forwardAppRoot = forwardAppRoot;
        this.numberSupported = false;
        this.serviceName = serviceName;
    }

    LookupConsumerAsset(String forwardAppRoot) {
        this.forwardAppRoot = forwardAppRoot;

        searchSupported = false;
        idSupported = false;
        numberSupported = false;
        this.serviceName = DEFAULT_HOST_SERVICE;
    }

    LookupConsumerAsset(

            boolean searchSupported, boolean idSupported, String forwardAppRoot, boolean numberSupported) {

        this.searchSupported = searchSupported;
        this.idSupported = idSupported;
        this.forwardAppRoot = forwardAppRoot;
        this.numberSupported = numberSupported;
        this.serviceName = DEFAULT_HOST_SERVICE;
    }

    LookupConsumerAsset(boolean searchSupported, boolean idSupported, String forwardAppRoot) {

        this.searchSupported = searchSupported;
        this.idSupported = idSupported;
        this.forwardAppRoot = forwardAppRoot;
        this.numberSupported = false;
        this.serviceName = DEFAULT_HOST_SERVICE;
    }





}
