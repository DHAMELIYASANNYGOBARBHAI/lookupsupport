package com.tekion.lookuphelper;

import com.tekion.admin.beans.workspace.Workspace;
import com.tekion.clients.preference.beans.responseEntity.TResponse;
import com.tekion.clients.preference.client.PreferenceClient;
import com.tekion.core.utils.TCollectionUtils;
import com.tekion.core.utils.UserContextProvider;
import com.tekion.lookuphelper.dto.request.*;
import com.tekion.lookuphelper.dto.response.LookupEntity;
import com.tekion.lookuphelper.dto.response.LookupSearchResponse;
import com.tekion.lookuphelper.utils.TConstants;
import lombok.RequiredArgsConstructor;

import java.util.*;
import java.util.stream.Collectors;

import static com.tekion.core.utils.TCollectionUtils.nullSafeEmptyCollection;
import static com.tekion.core.utils.TCollectionUtils.transformToMap;

@RequiredArgsConstructor
public abstract class AbstractWorkspaceLookupService<T, E> implements WorkspaceLookupService<T, E> {

    private final PreferenceClient preferenceClient;

    @Override
    public Map<String, List<LookupEntity<E>>> lookupByIds(WorkspaceLookupRequestByIds workspaceLookupRequestByIds) {


        List<WorkspaceByIds> updatedLookupRequest = removeInaccessibleDealers(workspaceLookupRequestByIds);

        workspaceLookupRequestByIds.setWorkspaceByIds(updatedLookupRequest);

        if (updatedLookupRequest.isEmpty()) {
            return Collections.emptyMap();
        }
        return doLookupByIds(workspaceLookupRequestByIds);
    }

    private List<WorkspaceByIds> removeInaccessibleDealers(WorkspaceLookupRequestByIds workspaceLookupRequestByIds) {


        Map<String, List<String>> lookupRequest = workspaceLookupRequestByIds.getWorkspaceByIds().stream().collect(
                Collectors.toMap(WorkspaceByIds::getDealerId, WorkspaceByIds::getIds));

        List<WorkspaceByIds> updatedLookupRequest = new ArrayList<>();
        nullSafeEmptyCollection(getWorkspaceDealers()).forEach(dealerId -> {
            if (lookupRequest.containsKey(dealerId)) {
                updatedLookupRequest.add(new WorkspaceByIds(dealerId, lookupRequest.get(dealerId)));
            }
        });

        return updatedLookupRequest;
    }

    private List<String> getWorkspaceDealers() {
        return getWorkspaceDealers(UserContextProvider.getCurrentDealerId());
    }

    private List<String> getWorkspaceDealers(String dealerId) {
        TResponse<Workspace> response = preferenceClient.getWorkspaceByWorkspaceId(dealerId);
        if (response.getData() == null) {
            return Collections.emptyList();
        }
        return response.getData().getAccessibleDealerIds();
    }

    @Override
    public Map<String, List<LookupEntity<E>>> lookupByNumber(
            WorkspaceLookupRequestByNumbers workspaceLookupRequestByNumbers) {

        List<WorkspaceByNumbers> updatedLookupRequest = removeInaccessibleDealers(workspaceLookupRequestByNumbers);
        workspaceLookupRequestByNumbers.setWorkspaceByNumbers(updatedLookupRequest);
        if (updatedLookupRequest.isEmpty()) {
            return Collections.emptyMap();
        }
        return doLookupByNumber(workspaceLookupRequestByNumbers);


    }

    private List<WorkspaceByNumbers> removeInaccessibleDealers(
            WorkspaceLookupRequestByNumbers workspaceLookupRequestByNumbers) {


        Map<String, List<String>> lookupRequest = workspaceLookupRequestByNumbers.getWorkspaceByNumbers().stream()
                                                                                 .collect(Collectors.toMap(
                                                                                         WorkspaceByNumbers::getDealerId,
                                                                                         WorkspaceByNumbers::getNumbers));

        List<WorkspaceByNumbers> updatedLookupRequest = new ArrayList<>();
        nullSafeEmptyCollection(getWorkspaceDealers()).forEach(dealerId -> {
            if (lookupRequest.containsKey(dealerId)) {
                updatedLookupRequest.add(new WorkspaceByNumbers(dealerId, lookupRequest.get(dealerId)));
            }
        });

        return updatedLookupRequest;
    }


    @Override
    public LookupSearchResponse lookupBySearch(WorkspaceLookupRequestBySearch workspaceLookupRequestBySearch) {

        workspaceLookupRequestBySearch.setDealerIds(
                removeInaccessibleDealers(workspaceLookupRequestBySearch.getDealerIds()));

        if (TCollectionUtils.isEmpty(workspaceLookupRequestBySearch.getDealerIds())) {
            return TConstants.EMPTY_SEARCH_RESPONSE;
        }
        return doLookupSearch(workspaceLookupRequestBySearch);
    }

    private List<String> removeInaccessibleDealers(List<String> dealers) {
        Map<String, String> workspaceDealersMap = transformToMap(getWorkspaceDealers(), x -> x);
        return nullSafeEmptyCollection(dealers).stream().filter(workspaceDealersMap::containsKey)
                                               .collect(Collectors.toList());
    }




    protected abstract Map<String, List<LookupEntity<E>>> doLookupByIds(
            WorkspaceLookupRequestByIds workspaceLookupRequestByIds);

    protected abstract LookupSearchResponse doLookupSearch(
            WorkspaceLookupRequestBySearch workspaceLookupRequestBySearch);

    protected abstract Map<String, List<LookupEntity<E>>> doLookupByNumber(
            WorkspaceLookupRequestByNumbers workspaceLookupRequestByNumbers);
}
