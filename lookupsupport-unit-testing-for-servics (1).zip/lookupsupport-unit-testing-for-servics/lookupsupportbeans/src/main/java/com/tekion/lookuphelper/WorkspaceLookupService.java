package com.tekion.lookuphelper;

import com.tekion.lookuphelper.dto.request.WorkspaceLookupRequestByIds;
import com.tekion.lookuphelper.dto.request.WorkspaceLookupRequestByNumbers;
import com.tekion.lookuphelper.dto.request.WorkspaceLookupRequestBySearch;
import com.tekion.lookuphelper.dto.response.LookupEntity;
import com.tekion.lookuphelper.dto.response.LookupSearchResponse;

import java.util.List;
import java.util.Map;

public interface WorkspaceLookupService<T, E> {

    List<T> getSupportedLookupAssets();

    Map<String, List<LookupEntity<E>>> lookupByIds(WorkspaceLookupRequestByIds workspaceLookupRequestByIds);

    LookupSearchResponse lookupBySearch(WorkspaceLookupRequestBySearch workspaceLookupRequestBySearch);

    Map<String, List<LookupEntity<E>>> lookupByNumber(WorkspaceLookupRequestByNumbers workspaceLookupRequestByNumbers);
}
