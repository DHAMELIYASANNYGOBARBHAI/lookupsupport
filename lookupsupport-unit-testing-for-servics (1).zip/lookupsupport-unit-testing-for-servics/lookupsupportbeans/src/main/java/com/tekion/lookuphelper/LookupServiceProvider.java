package com.tekion.lookuphelper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class LookupServiceProvider {
    public final Map<LookupConsumerAsset, AbstractLookupService> assetVsServiceMap;

    @Autowired
    public LookupServiceProvider(List<AbstractLookupService> lookupServices) {
        Map<LookupConsumerAsset, AbstractLookupService> assetVsServiceHelperMap = new HashMap<>();
        lookupServices.forEach(lookupService -> {
            List<LookupConsumerAsset> lookupAssets = lookupService.getSupportedLookupAssets();
            lookupAssets.forEach(key -> {
                assetVsServiceHelperMap.put(key, lookupService);
            });
        });
        this.assetVsServiceMap = assetVsServiceHelperMap;
    }

    public AbstractLookupService getServiceForLookupAsset(LookupConsumerAsset lookupAsset) {
        return this.assetVsServiceMap.get(lookupAsset);
    }

}
