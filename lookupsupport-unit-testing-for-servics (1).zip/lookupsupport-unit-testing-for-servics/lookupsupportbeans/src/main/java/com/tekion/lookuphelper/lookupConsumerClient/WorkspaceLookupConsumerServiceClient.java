package com.tekion.lookuphelper.lookupConsumerClient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.tekion.core.utils.TCollectionUtils;
import com.tekion.core.utils.TJsonUtils;
import com.tekion.lookupconsumer.LookupConsumerService;
import com.tekion.lookuphelper.WorkspaceLookupAsset;
import com.tekion.lookuphelper.dto.request.*;
import com.tekion.lookuphelper.dto.response.LookupEntity;
import com.tekion.lookuphelper.dto.response.LookupSearchResponse;
import com.tekion.lookuphelper.utils.TConstants;
import com.tekion.lookupsupport.beans.WorkspaceLookupSearchReq;
import com.tekion.tekionconstant.lookupconsumer.LookupAsset;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.*;

import static com.tekion.lookuphelper.utils.LookupUtils.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class WorkspaceLookupConsumerServiceClient {

    private final LookupConsumerService lookupConsumerService;

    public Map<WorkspaceLookupAsset, Map<String, List<LookupEntity>>> workspaceLookupByIds(
            BulkWorkspaceLookupRequestByIds bulkWorkspaceLookupRequestByIds) {
        Map<LookupAsset, Map<String, List<String>>> requestMap = new HashMap<>();
        Map<String, List<String>> dealerToIdsMap = new HashMap<>();
        Map<LookupAsset, JsonNode> lookupResponse = new HashMap<>();
        Map<WorkspaceLookupAsset, Map<String, List<LookupEntity>>> finalResponse = new HashMap<>();
        for (WorkspaceLookupRequestByIds workspaceLookupRequestByIds : TCollectionUtils.nullSafeList(
                bulkWorkspaceLookupRequestByIds.getWorkspaceLookupRequestByIds())) {
            for (WorkspaceByIds workspaceByIds :
                    TCollectionUtils.nullSafeList(workspaceLookupRequestByIds.getWorkspaceByIds())) {
                dealerToIdsMap.put(workspaceByIds.getDealerId(), workspaceByIds.getIds());
            }
            requestMap.put(newLookupAssetToOldLookupAsset(workspaceLookupRequestByIds.getAssetType()), dealerToIdsMap);
        }
        try {
            lookupResponse = lookupConsumerService.workspaceLookupIds(requestMap);
        } catch (Exception e) {
            log.error("Exception in lookupConsumerService.workspaceLookupByIds ", e);
        }
        for (LookupAsset lookupAsset : lookupResponse.keySet()) {
            finalResponse.put(oldLookupAssetToNewWorkspaceLookupAsset(lookupAsset),
                    workspaceLookupResponseMapper(lookupResponse));
        }
        return finalResponse;
    }

    public Map<WorkspaceLookupAsset, Map<String, List<LookupEntity>>> workspaceLookupByNumbers(
            BulkWorkspaceLookupRequestByNumbers bulkWorkspaceLookupRequestByNumbers) {
        Map<LookupAsset, Map<String, List<String>>> requestMap = new HashMap<>();
        Map<String, List<String>> dealerToNumbersMap = new HashMap<>();
        Map<LookupAsset, JsonNode> lookupResponse = new HashMap<>();
        Map<WorkspaceLookupAsset, Map<String, List<LookupEntity>>> finalResponse = new HashMap<>();
        for (WorkspaceLookupRequestByNumbers workspaceLookupRequestByNumbers : TCollectionUtils.nullSafeList(
                bulkWorkspaceLookupRequestByNumbers.getWorkspaceLookupRequestByNumbers())) {
            for (WorkspaceByNumbers workspaceByNumbers :
                    TCollectionUtils.nullSafeList(workspaceLookupRequestByNumbers.getWorkspaceByNumbers())) {
                dealerToNumbersMap.put(workspaceByNumbers.getDealerId(), workspaceByNumbers.getNumbers());
            }
            requestMap.put(newLookupAssetToOldLookupAsset(workspaceLookupRequestByNumbers.getAssetType()),
                    dealerToNumbersMap);
        }
        try {
            lookupResponse = lookupConsumerService.workspaceLookupNumbers(requestMap);
        } catch (Exception e) {
            log.error("Exception in lookupConsumerService.workspaceLookupByNumbers ", e);
        }
        for (LookupAsset lookupAsset : lookupResponse.keySet()) {
            finalResponse.put(oldLookupAssetToNewWorkspaceLookupAsset(lookupAsset),
                    workspaceLookupResponseMapper(lookupResponse));
        }
        return finalResponse;
    }

    public Map<WorkspaceLookupAsset, LookupSearchResponse> workspaceLookupBySearch(
            BulkWorkspaceLookupRequestBySearch bulkWorkspaceLookupRequestBySearch) {
        Map<LookupAsset, JsonNode> requestMap = new HashMap<>();
        Map<LookupAsset, JsonNode> lookupResponse = new HashMap<>();
        Map<WorkspaceLookupAsset, LookupSearchResponse> finalResponse = new HashMap<>();
        for (WorkspaceLookupRequestBySearch workspaceLookupRequestBySearch : TCollectionUtils.nullSafeList(
                bulkWorkspaceLookupRequestBySearch.getWorkspaceLookupRequestBySearch())) {
            WorkspaceLookupSearchReq workspaceLookupSearchReq = new WorkspaceLookupSearchReq();
            BeanUtils.copyProperties(workspaceLookupRequestBySearch.getSearchRequest(), workspaceLookupSearchReq);
            workspaceLookupSearchReq.setDealerIds(workspaceLookupRequestBySearch.getDealerIds());
            requestMap.put(LookupAsset.valueOf(workspaceLookupRequestBySearch.getAssetType().name()),
                    TJsonUtils.getDefaultSharedMapper().valueToTree(workspaceLookupSearchReq));
        }
        try {
            lookupResponse = lookupConsumerService.workspaceLookupSearchRequest(requestMap);
        } catch (Exception e) {
            log.error("Exception in lookupConsumerService.workspaceLookupBySearch ", e);
        }
        for (LookupAsset lookupAsset : lookupResponse.keySet()) {
            finalResponse.put(oldLookupAssetToNewWorkspaceLookupAsset(lookupAsset),
                    lookupSearchResponseMapper(lookupResponse.get(lookupAsset)));
        }
        return finalResponse;
    }

    private Map<String, List<LookupEntity>> workspaceLookupResponseMapper(Map<LookupAsset, JsonNode> lookupResponse) {
        Map<String, List<LookupEntity>> finalResponse = new HashMap<>();
        Map<String, JsonNode> intermediateMap = new HashMap<>();
        for (LookupAsset lookupAsset : lookupResponse.keySet()) {
            intermediateMap = TJsonUtils.getDefaultSharedMapper().convertValue(lookupResponse.get(lookupAsset),
                    new TypeReference<Map<String, JsonNode>>() {

                    });
        }
        for (String dealerId : intermediateMap.keySet()) {
            JsonNode data = intermediateMap.get(dealerId);
            List<LookupEntity> lookupEntityList = new ArrayList<>();
            if (data.isArray()) {
                Iterator<JsonNode> jsonNodeIterator = data.elements();
                while (jsonNodeIterator.hasNext()) {
                    JsonNode arrayNode = jsonNodeIterator.next();
                    if (arrayNode.has(TConstants.DATA)) {
                        try {
                            LookupEntity lookupEntity = TJsonUtils.getDefaultSharedMapper()
                                                                  .treeToValue(arrayNode, LookupEntity.class);
                            lookupEntityList.add(lookupEntity);
                        } catch (JsonProcessingException e) {
                            log.error("Unable to convert workspaceLookupRequest", e);
                        }
                    } else {
                        try {
                            Object object = TJsonUtils.getDefaultSharedMapper().treeToValue(arrayNode, Object.class);
                            String id = arrayNode.has(TConstants.ID) ? arrayNode.get(TConstants.ID).asText() : null;
                            LookupEntity lookupEntity = new LookupEntity<>(id, null, object);
                            lookupEntityList.add(lookupEntity);
                        } catch (JsonProcessingException e) {
                            log.error("Unable to convert workspaceLookupRequest", e);
                        }
                    }
                }
            }
            finalResponse.put(dealerId, lookupEntityList);
        }
        return finalResponse;
    }
}
