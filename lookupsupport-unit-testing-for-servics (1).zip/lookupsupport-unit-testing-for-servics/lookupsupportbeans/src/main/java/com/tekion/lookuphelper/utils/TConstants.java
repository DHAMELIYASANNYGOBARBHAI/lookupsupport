package com.tekion.lookuphelper.utils;

import com.tekion.lookuphelper.dto.response.LookupSearchResponse;

import java.util.Collections;

public class TConstants {

    public static final LookupSearchResponse EMPTY_SEARCH_RESPONSE = new LookupSearchResponse(Collections.emptyList(),
            0);
    public static final String DATA = "data";
    public static final String ID = "id";
    public static final String ENTITIES = "entities";
    public static final String DISPLAY_ID = "displayId";
}
