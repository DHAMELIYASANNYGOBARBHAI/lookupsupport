package com.tekion.lookuphelper;

import com.tekion.lookuphelper.dto.request.*;
import com.tekion.lookuphelper.dto.response.LookupEntity;
import com.tekion.lookuphelper.dto.response.LookupSearchResponse;
import com.tekion.lookuphelper.lookupConsumerClient.WorkspaceLookupConsumerServiceClient;
import com.tekion.lookuphelper.utils.TConstants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static org.apache.commons.collections4.MapUtils.emptyIfNull;
import static org.apache.commons.collections4.ListUtils.emptyIfNull;

@Service
@Slf4j
@RequiredArgsConstructor
public class WorkspaceMultiLookupServiceV2 {

    private final WorkspaceLookupServiceProvider workspaceLookupServiceProvider;
    private final WorkspaceLookupConsumerServiceClient workspaceLookupConsumerServiceClient;

    public Map<IWorkspaceLookupAsset, Map<String, List<LookupEntity>>> doLookupByIds(
            BulkWorkspaceLookupRequestByIds bulkWorkspaceLookupRequestByIds) {

        Map<IWorkspaceLookupAsset, Map<String, List<LookupEntity>>> resultMap = new HashMap<>();
        Map<String, BulkWorkspaceLookupRequestByIds> forwardAppRootVsLookupRequestMap = new HashMap<>();

        for (WorkspaceLookupRequestByIds workspaceLookupRequestByIds : emptyIfNull(
                bulkWorkspaceLookupRequestByIds.getWorkspaceLookupRequestByIds())) {
            WorkspaceLookupService workspaceLookupService = workspaceLookupServiceProvider.getServiceForLookupAsset(
                    workspaceLookupRequestByIds.getAssetType());

            if (Objects.nonNull(workspaceLookupService)) {
                Map<String, List<LookupEntity>> dealerWiseResult = Collections.emptyMap();
                try {
                    dealerWiseResult = workspaceLookupService.lookupByIds(workspaceLookupRequestByIds);
                } catch (Exception exception) {
                    log.error("Lookup failed for asset {}", workspaceLookupRequestByIds.getAssetType(), exception);
                }
                resultMap.put(workspaceLookupRequestByIds.getAssetType(), dealerWiseResult);
            } else {
                String forwardAppRoot = workspaceLookupRequestByIds.getAssetType().getForwardAppRoot();
                forwardAppRootVsLookupRequestMap
                        .computeIfAbsent(forwardAppRoot, key -> new BulkWorkspaceLookupRequestByIds(new ArrayList<>()))
                        .getWorkspaceLookupRequestByIds().add(workspaceLookupRequestByIds);
            }

        }
        resultMap.putAll(emptyIfNull(workSpaceLookupByIdsToExternalServices(forwardAppRootVsLookupRequestMap)));
        return resultMap;
    }

    private Map<IWorkspaceLookupAsset, Map<String, List<LookupEntity>>> workSpaceLookupByIdsToExternalServices(
            Map<String, BulkWorkspaceLookupRequestByIds> forwardAppRootVsLookupRequestMap) {
        Map<IWorkspaceLookupAsset, Map<String, List<LookupEntity>>> resultMap = new HashMap<>();
        for (Map.Entry<String, BulkWorkspaceLookupRequestByIds> entryForEachForwardAppRoot : emptyIfNull(
                forwardAppRootVsLookupRequestMap).entrySet()) {
            String forwardAppRoot = entryForEachForwardAppRoot.getKey();
            BulkWorkspaceLookupRequestByIds bulkWorkspaceLookupRequestByIds = entryForEachForwardAppRoot.getValue();
            try {
                resultMap.putAll(emptyIfNull(
                        workspaceLookupConsumerServiceClient.workspaceLookupByIds(bulkWorkspaceLookupRequestByIds)));
            } catch (Exception exception) {
                log.error("Lookup failed for assets {} for forward app root {}",
                        bulkWorkspaceLookupRequestByIds.getWorkspaceLookupRequestByIds().stream()
                                                       .map(WorkspaceLookupRequestByIds::getAssetType)
                                                       .collect(Collectors.toList()).toString(), forwardAppRoot);
            }
        }
        return resultMap;
    }

    public Map<IWorkspaceLookupAsset, Map<String, List<LookupEntity>>> doLookupByNumber(
            BulkWorkspaceLookupRequestByNumbers bulkWorkspaceLookupRequestByNumbers) {

        Map<IWorkspaceLookupAsset, Map<String, List<LookupEntity>>> resultMap = new HashMap<>();
        Map<String, BulkWorkspaceLookupRequestByNumbers> forwardAppRootVsLookupRequestMap = new HashMap<>();

        for (WorkspaceLookupRequestByNumbers workspaceLookupRequestByNumbers : emptyIfNull(
                bulkWorkspaceLookupRequestByNumbers.getWorkspaceLookupRequestByNumbers())) {
            WorkspaceLookupService workspaceLookupService = workspaceLookupServiceProvider.getServiceForLookupAsset(
                    workspaceLookupRequestByNumbers.getAssetType());

            if (Objects.nonNull(workspaceLookupService)) {
                Map<String, List<LookupEntity>> dealerWiseResult = Collections.emptyMap();
                try {
                    dealerWiseResult = workspaceLookupService.lookupByNumber(workspaceLookupRequestByNumbers);
                } catch (Exception exception) {
                    log.error("Lookup failed for asset {}", workspaceLookupRequestByNumbers.getAssetType(), exception);
                }
                resultMap.put(workspaceLookupRequestByNumbers.getAssetType(), dealerWiseResult);
            } else {
                String forwardAppRoot = workspaceLookupRequestByNumbers.getAssetType().getForwardAppRoot();
                forwardAppRootVsLookupRequestMap.computeIfAbsent(forwardAppRoot,
                                                        key -> new BulkWorkspaceLookupRequestByNumbers(new ArrayList<>()))
                                                .getWorkspaceLookupRequestByNumbers()
                                                .add(workspaceLookupRequestByNumbers);
            }
        }
        resultMap.putAll(emptyIfNull(workSpaceLookupByNumbersToExternalServices(forwardAppRootVsLookupRequestMap)));
        return resultMap;
    }

    private Map<IWorkspaceLookupAsset, Map<String, List<LookupEntity>>> workSpaceLookupByNumbersToExternalServices(
            Map<String, BulkWorkspaceLookupRequestByNumbers> forwardAppRootVsLookupRequestMap) {
        Map<IWorkspaceLookupAsset, Map<String, List<LookupEntity>>> resultMap = new HashMap<>();
        for (Map.Entry<String, BulkWorkspaceLookupRequestByNumbers> entryForEachForwardAppRoot : emptyIfNull(
                forwardAppRootVsLookupRequestMap).entrySet()) {
            String forwardAppRoot = entryForEachForwardAppRoot.getKey();
            BulkWorkspaceLookupRequestByNumbers bulkWorkspaceLookupRequestByNumbers
                    = entryForEachForwardAppRoot.getValue();
            try {
                resultMap.putAll(emptyIfNull(workspaceLookupConsumerServiceClient.workspaceLookupByNumbers(
                        bulkWorkspaceLookupRequestByNumbers)));
            } catch (Exception exception) {
                log.error("Lookup failed for assets {} for forward app root {}",
                        bulkWorkspaceLookupRequestByNumbers.getWorkspaceLookupRequestByNumbers().stream()
                                                           .map(WorkspaceLookupRequestByNumbers::getAssetType)
                                                           .collect(Collectors.toList()).toString(), forwardAppRoot);
            }
        }
        return resultMap;
    }

    public Map<IWorkspaceLookupAsset, LookupSearchResponse> doLookupSearch(
            BulkWorkspaceLookupRequestBySearch bulkWorkspaceLookupRequestBySearch) {

        Map<IWorkspaceLookupAsset, LookupSearchResponse> resultMap = new HashMap<>();
        Map<String, BulkWorkspaceLookupRequestBySearch> forwardAppRootVsLookupRequestMap = new HashMap<>();

        for (WorkspaceLookupRequestBySearch workspaceLookupRequestBySearch : emptyIfNull(
                bulkWorkspaceLookupRequestBySearch.getWorkspaceLookupRequestBySearch())) {
            WorkspaceLookupService workspaceLookupService = workspaceLookupServiceProvider.getServiceForLookupAsset(
                    workspaceLookupRequestBySearch.getAssetType());

            if (Objects.nonNull(workspaceLookupService)) {
                LookupSearchResponse lookupSearchResponse = TConstants.EMPTY_SEARCH_RESPONSE;
                try {
                    lookupSearchResponse = workspaceLookupService.lookupBySearch(workspaceLookupRequestBySearch);
                } catch (Exception exception) {
                    log.error("Lookup failed for asset {}", workspaceLookupRequestBySearch.getAssetType(), exception);
                }
                resultMap.put(workspaceLookupRequestBySearch.getAssetType(), lookupSearchResponse);
            } else {
                String forwardAppRoot = workspaceLookupRequestBySearch.getAssetType().getForwardAppRoot();
                forwardAppRootVsLookupRequestMap.computeIfAbsent(forwardAppRoot,
                                                        key -> new BulkWorkspaceLookupRequestBySearch(new ArrayList<>()))
                                                .getWorkspaceLookupRequestBySearch()
                                                .add(workspaceLookupRequestBySearch);
            }
        }
        resultMap.putAll(emptyIfNull(workSpaceLookupBySearchToExternalServices(forwardAppRootVsLookupRequestMap)));
        return resultMap;
    }

    private Map<IWorkspaceLookupAsset, LookupSearchResponse> workSpaceLookupBySearchToExternalServices(
            Map<String, BulkWorkspaceLookupRequestBySearch> forwardAppRootVsLookupRequestMap) {
        Map<IWorkspaceLookupAsset, LookupSearchResponse> resultMap = new HashMap<>();
        for (Map.Entry<String, BulkWorkspaceLookupRequestBySearch> entryForEachForwardAppRoot : emptyIfNull(
                forwardAppRootVsLookupRequestMap).entrySet()) {
            String forwardAppRoot = entryForEachForwardAppRoot.getKey();
            BulkWorkspaceLookupRequestBySearch bulkWorkspaceLookupRequestBySearch
                    = entryForEachForwardAppRoot.getValue();
            try {
                resultMap.putAll(emptyIfNull(workspaceLookupConsumerServiceClient.workspaceLookupBySearch(
                        bulkWorkspaceLookupRequestBySearch)));
            } catch (Exception exception) {
                log.error("Lookup failed for assets {} for forward app root {}",
                        bulkWorkspaceLookupRequestBySearch.getWorkspaceLookupRequestBySearch().stream()
                                                          .map(WorkspaceLookupRequestBySearch::getAssetType)
                                                          .collect(Collectors.toList()).toString(), forwardAppRoot);
            }
        }
        return resultMap;
    }
}
