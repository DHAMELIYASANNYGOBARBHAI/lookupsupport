package com.tekion.lookuphelper;

import com.tekion.core.utils.TCollectionUtils;
import com.tekion.lookuphelper.dto.request.*;
import com.tekion.lookuphelper.dto.response.LookupEntity;
import com.tekion.lookuphelper.dto.response.LookupSearchResponse;
import com.tekion.lookuphelper.utils.TConstants;
import lombok.extern.slf4j.Slf4j;

import java.util.*;

@Slf4j
public abstract class AbstractLookupService<T extends ILookupAsset> implements LookupService<T> {

    @Override
    public List<LookupEntity> lookupByIds(LookupRequestByIds lookupRequestByIds) {
        ILookupAsset lookupAsset = lookupRequestByIds.getAssetType();
        if (!lookupAsset.isIdSupported()) {
            log.error("Lookup not supported for {}", lookupAsset);
            throw new UnsupportedLookupOperationException(lookupAsset);
        }

        Map<T, List<LookupEntity>> result = doLookupByIds(
                new BulkLookupRequestByIds(Collections.singletonList(lookupRequestByIds)));
        if (TCollectionUtils.isNotEmpty(result)) {
            return TCollectionUtils.nullSafeList(result.get(lookupAsset));
        }
        return Collections.emptyList();
    }

    @Override
    public Map<T, List<LookupEntity>> bulkLookupByIds(BulkLookupRequestByIds bulkLookupRequestByIds) {
        return doLookupByIds(bulkLookupRequestByIds);
    }

    @Override
    public LookupSearchResponse lookupBySearch(LookupRequestBySearch lookupRequestBySearch) {
        ILookupAsset lookupAsset = lookupRequestBySearch.getAssetType();
        if (!lookupAsset.isSearchSupported()) {
            log.error("Lookup not supported for {}", lookupAsset);
            throw new UnsupportedLookupOperationException(lookupAsset);
        }

        Map<T, LookupSearchResponse> result = doLookupBySearch(
                new BulkLookupRequestBySearch(Collections.singletonList(lookupRequestBySearch)));
        if (TCollectionUtils.isNotEmpty(result)) {
            return result.get(lookupAsset);
        }
        return TConstants.EMPTY_SEARCH_RESPONSE;
    }

    @Override
    public Map<T, LookupSearchResponse> bulkLookupBySearch(BulkLookupRequestBySearch bulkLookupRequestBySearch) {
        return doLookupBySearch(bulkLookupRequestBySearch);
    }

    @Override
    public List<LookupEntity> lookupByNumber(LookupRequestByNumbers lookupRequestByNumbers) {
        ILookupAsset lookupAsset = lookupRequestByNumbers.getAssetType();
        if (!lookupAsset.isNumberSupported()) {
            log.error("Lookup not supported for {}", lookupAsset);
            throw new UnsupportedLookupOperationException(lookupAsset);
        }

        final Map<T, List<LookupEntity>> result = doLookupByNumber(
                new BulkLookupRequestByNumbers(Collections.singletonList(lookupRequestByNumbers)));
        if (TCollectionUtils.isNotEmpty(result)) {
            return TCollectionUtils.nullSafeList(result.get(lookupRequestByNumbers.getAssetType()));
        }
        return Collections.emptyList();
    }


    @Override
    public Map<T, List<LookupEntity>> bulkLookupByNumber(BulkLookupRequestByNumbers bulkLookupRequestByNumbers) {
        return doLookupByNumber(bulkLookupRequestByNumbers);
    }

    protected abstract Map<T, List<LookupEntity>> doLookupByIds(BulkLookupRequestByIds bulkLookupRequestByIds);

    protected abstract Map<T, LookupSearchResponse> doLookupBySearch(
            BulkLookupRequestBySearch bulkLookupRequestBySearch);


    protected abstract Map<T, List<LookupEntity>> doLookupByNumber(
            BulkLookupRequestByNumbers bulkLookupRequestByNumbers);
}
