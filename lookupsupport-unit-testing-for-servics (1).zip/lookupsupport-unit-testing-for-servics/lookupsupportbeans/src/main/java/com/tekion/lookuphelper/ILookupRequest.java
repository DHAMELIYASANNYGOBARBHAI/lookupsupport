package com.tekion.lookuphelper;

import java.util.List;

public interface ILookupRequest {

    List<String> getIncludeFields();
    List<String> getExcludeFields();
}
