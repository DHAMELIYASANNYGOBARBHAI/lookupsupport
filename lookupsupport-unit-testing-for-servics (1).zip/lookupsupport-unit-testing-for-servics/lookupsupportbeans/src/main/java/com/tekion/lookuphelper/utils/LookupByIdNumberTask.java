package com.tekion.lookuphelper.utils;

import java.util.List;

public interface LookupByIdNumberTask<T> {

    T getResult(List<String> assetNumberOrIds);
}
