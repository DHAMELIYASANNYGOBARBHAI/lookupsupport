package com.tekion.lookuphelper.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class WorkspaceByNumbers {

    @NotBlank
    private String dealerId;
    @NotEmpty
    private List<String> numbers;
}
