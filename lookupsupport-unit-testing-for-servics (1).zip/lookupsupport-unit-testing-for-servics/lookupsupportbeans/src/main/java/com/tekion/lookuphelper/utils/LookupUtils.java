package com.tekion.lookuphelper.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.tekion.core.es.common.i.ITekSearchRequest;
import com.tekion.core.utils.TCollectionUtils;
import com.tekion.core.utils.TJsonUtils;
import com.tekion.core.utils.UserContext;
import com.tekion.core.utils.UserContextProvider;
import com.tekion.lookuphelper.ILookupAsset;
import com.tekion.lookuphelper.ILookupRequest;
import com.tekion.lookuphelper.LookupConsumerAsset;
import com.tekion.lookuphelper.WorkspaceLookupAsset;
import com.tekion.lookuphelper.dto.request.WorkspaceByIds;
import com.tekion.lookuphelper.dto.request.WorkspaceLookupRequestByIds;
import com.tekion.lookuphelper.dto.response.LookupSearchResponse;
import com.tekion.tekionconstant.lookupconsumer.LookupAsset;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.task.AsyncTaskExecutor;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import static com.tekion.core.utils.TCollectionUtils.isEmpty;

@Slf4j
@UtilityClass
public class LookupUtils {

    public static <T> Map<String, List<T>> resolveFutures(Map<String, List<T>> response,
                                                          Map<String, Future<List<T>>> futureMap) {
        for (String dealerId : TCollectionUtils.nullSafeMap(futureMap).keySet()) {
            try {
                response.put(dealerId, futureMap.get(dealerId).get());
            } catch (Exception e) {
                log.error("[lookup] error ", e);
            }
        }
        return response;
    }

    public static <T> void getLookupResponseForWorkSpace(Map<String, List<String>> lookupRequest,
                                                         Map<String, Future<List<T>>> futureMap,
                                                         AsyncTaskExecutor executorService,
                                                         LookupByIdNumberTask<List<T>> lookupByIdNumberTask) {
        UserContext originalContext = UserContextProvider.getContext();
        try {
            for (String dealerId : lookupRequest.keySet()) {
                Callable task = () -> {
                    try {
                        UserContext dealerContext = new UserContext(originalContext.getUserId(),
                                originalContext.getTenantId(), dealerId);
                        UserContextProvider.setContext(dealerContext);
                        List<String> glAccountIds = TCollectionUtils.nullSafeList(lookupRequest.get(dealerId));
                        if (TCollectionUtils.isNotEmpty(glAccountIds)) {
                            return lookupByIdNumberTask.getResult(glAccountIds);
                        }
                    } catch (Exception e) {
                        log.error("[lookup] workspace error ", e);
                    } finally {
                        UserContextProvider.unsetContext();
                    }
                    return Lists.newArrayList();
                };
                futureMap.put(dealerId, executorService.submit(task));
            }
        } finally {
            UserContextProvider.setContext(originalContext);
        }
    }

    public static Map<String, List<String>> getDealerIdVsWorkspaceLookupRequestByIdsMap(
            WorkspaceLookupRequestByIds workspaceLookupRequestByIds) {
        Map<String, List<String>> lookupIdsForDealersMap = workspaceLookupRequestByIds.getWorkspaceByIds().stream()
                                                                                      .collect(Collectors.toMap(
                                                                                              WorkspaceByIds::getDealerId,
                                                                                              WorkspaceByIds::getIds));

        return lookupIdsForDealersMap;
    }

    public static List<String> getIncludedFieldsWithGivenAnnotation(Object object, List<String> excludedList,
                                                                    Class className) {
        List<String> includedList = new ArrayList<>();

        Field[] fields = object.getClass().getDeclaredFields();
        for (Field field : fields) {
            if (!Modifier.isStatic(field.getModifiers()) && !excludedList.contains(field.getName()) &&
                isFieldAnnotatedWithGivenColumn(field, className)) {
                includedList.add(field.getName());
            }
        }
        return includedList;
    }

    private static boolean isFieldAnnotatedWithGivenColumn(Field field, Class className) {
        return field.isAnnotationPresent(className);
    }

    public static boolean isBothIncludeAndExcludeFieldEmpty(ILookupRequest lookupRequest) {
        return isEmpty(lookupRequest.getIncludeFields()) && isEmpty(lookupRequest.getExcludeFields());
    }

    public static boolean isBothIncludeAndExcludeFieldEmpty(ITekSearchRequest tekSearchRequest) {
        return isEmpty(tekSearchRequest.getIncludeFields()) && isEmpty(tekSearchRequest.getExcludeFields());
    }

    public static LookupSearchResponse lookupSearchResponseMapper(JsonNode data) {
        LookupSearchResponse response = new LookupSearchResponse();
        try {
            response = TJsonUtils.getDefaultSharedMapper().treeToValue(data, LookupSearchResponse.class);
        } catch (JsonProcessingException e) {
            log.error("Unable to convert lookupSearch request", e);
        }
        return response;
    }

    public static LookupConsumerAsset oldLookupAssetToNewLookupAsset(LookupAsset lookupAsset) {
        return LookupConsumerAsset.valueOf(lookupAsset.name());
    }

    public static LookupAsset newLookupAssetToOldLookupAsset(ILookupAsset lookupAsset) {
        return LookupAsset.valueOf(lookupAsset.name());
    }

    public static WorkspaceLookupAsset oldLookupAssetToNewWorkspaceLookupAsset(LookupAsset lookupAsset) {
        return WorkspaceLookupAsset.valueOf(lookupAsset.name());
    }
}
