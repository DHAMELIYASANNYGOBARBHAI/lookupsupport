package com.tekion.lookuphelper.dto.request;

import com.tekion.core.es.common.impl.TekSearchRequest;
import com.tekion.lookuphelper.WorkspaceLookupAsset;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class WorkspaceLookupRequestBySearch {

    @NotNull
    private WorkspaceLookupAsset assetType;
    @NotEmpty
    private List<String> dealerIds;
    private TekSearchRequest searchRequest;


}
