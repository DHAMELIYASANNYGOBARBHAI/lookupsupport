package com.tekion.lookuphelper.dto.request;

import com.tekion.lookuphelper.ILookupRequest;
import com.tekion.lookuphelper.LookupConsumerAsset;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LookupRequestByIds implements ILookupRequest {

    @NotNull
    private LookupConsumerAsset assetType;
    @NotEmpty
    private List<String> ids;
    private List<String> includeFields;
    private List<String> excludeFields;
    private boolean miniResponse;
}