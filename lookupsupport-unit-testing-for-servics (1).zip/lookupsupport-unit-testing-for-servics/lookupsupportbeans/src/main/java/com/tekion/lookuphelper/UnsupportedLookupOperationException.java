package com.tekion.lookuphelper;

import com.tekion.core.exceptions.TBaseRuntimeException;


public class UnsupportedLookupOperationException extends TBaseRuntimeException {

    public UnsupportedLookupOperationException(ILookupAsset asset) {
        super("lookup type not supported on this asset + " + asset.name());
    }

    public UnsupportedLookupOperationException(String asset) {
        super("lookup type not supported on this asset + " + asset);
    }
}
