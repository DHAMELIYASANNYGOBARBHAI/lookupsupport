package com.tekion.lookuphelper.api;

import com.tekion.core.service.api.TResponseEntityBuilder;
import com.tekion.core.validation.TValidator;
import com.tekion.lookuphelper.WorkspaceMultiLookupServiceV2;
import com.tekion.lookuphelper.dto.request.BulkWorkspaceLookupRequestByIds;
import com.tekion.lookuphelper.dto.request.BulkWorkspaceLookupRequestByNumbers;
import com.tekion.lookuphelper.dto.request.BulkWorkspaceLookupRequestBySearch;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/lookup/workspace/v2")
public class WorkspaceLookupControllerV2 {
    private final WorkspaceMultiLookupServiceV2 workspaceLookupService;
    private final TValidator tValidator;

    @PostMapping("/ids")
    public ResponseEntity workspaceLookupByIds(@RequestBody BulkWorkspaceLookupRequestByIds request) {
        tValidator.validate(request);
        return TResponseEntityBuilder.okResponseEntity(
                workspaceLookupService.doLookupByIds(request));
    }

    @PostMapping("/numbers")
    public ResponseEntity workspaceLookupByNumbers(@RequestBody BulkWorkspaceLookupRequestByNumbers request) {
        tValidator.validate(request);
        return TResponseEntityBuilder.okResponseEntity(
                workspaceLookupService.doLookupByNumber(request));
    }

    @PostMapping("/search")
    public ResponseEntity workspaceLookupBySearch(@RequestBody BulkWorkspaceLookupRequestBySearch request) {
        tValidator.validate(request);
        return TResponseEntityBuilder.okResponseEntity(
                workspaceLookupService.doLookupSearch(request));
    }
}
