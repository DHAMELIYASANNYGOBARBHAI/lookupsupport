package com.tekion.lookuphelper.dto.request;

import com.tekion.core.es.common.impl.TekSearchRequest;
import com.tekion.lookuphelper.LookupConsumerAsset;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LookupRequestBySearch {

    @NotNull
    private LookupConsumerAsset assetType;
    private TekSearchRequest searchRequest;

}
