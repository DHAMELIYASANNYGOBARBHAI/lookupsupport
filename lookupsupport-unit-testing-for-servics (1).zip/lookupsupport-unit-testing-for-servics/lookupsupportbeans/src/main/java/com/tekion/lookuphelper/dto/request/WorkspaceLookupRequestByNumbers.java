package com.tekion.lookuphelper.dto.request;

import com.tekion.lookuphelper.ILookupRequest;
import com.tekion.lookuphelper.WorkspaceLookupAsset;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class WorkspaceLookupRequestByNumbers implements ILookupRequest {

    @NotNull
    private WorkspaceLookupAsset assetType;
    @NotEmpty
    private List<WorkspaceByNumbers> workspaceByNumbers;
    private List<String> includeFields;
    private List<String> excludeFields;

}
