package com.tekion.lookuphelper;


import com.tekion.tekionconstant.permission.Permission;
import lombok.AllArgsConstructor;
import lombok.Getter;

import javax.validation.constraints.NotNull;

@AllArgsConstructor
@Getter
public enum WorkspaceLookupAsset implements IWorkspaceLookupAsset {

    GL_ACCOUNT_ASSET(true, true, false,true,"accounting"),
    JOURNAL_ASSET(false, true, false,true,"accounting"),
    PO_INVOICE_ASSET(false, true, false,true,"accounting"),
    VENDOR(true, true, true,true,"vms"),

    // todo to be Updated ...
    CUSTOMER(true,true,true,true,"cms"),
    FEE(true,true,true,true,"fee"),
    TICKET(true,true,true,true,"warranty"),
    PARTMASTER(true,true,true,true,"wms"),
    DELAERPART(true,true,true,true,"wms"),
    PARTINVENTORY(true,true,true,true,"wms"),
    PARTSALES(true,true,true,true,"partTrade"),
    PART_INVOICE(true,true,true,true,"partTrade"),
    PARTPO(true,true,true,true,"partTrade"),
    PART(true,true,true,true,"wms"),
    BINS(true,true,true,true,"wms"),
    PARTSOURCECODE(true,true,true,true,"wms"),
    PARTCUSTPRICE(true,true,true,true,"wms"),
    PARTPRICECODE(true,true,true,true,"wms"),
    PARTANDINVENTORY(true,true,true,true,"wms"),
    REPAIR_ORDER_ASSET(true,true,true,true,"ro"),
    OPCODE(true,true,true,true,"opcode"),
    SERVICE_TYPE(false,true,true,true,"opcode"),
    DEALS_BY_DEALNUMBER(true,true,true,true,"sales/core","DEALSERVICE"),
    VEHICLES_BY_ID(true,true,true,true,"vi"),
    VEHICLES_BY_VIN(true,true,true,true,"vi"),
    DSE_USER(false,true,true,true,"dse"),
    VEHICLE_BY_VIN(false,false,true,true,"dse"),
    DEALER_USER(true,true,true,true,"dse"),
    DSE_CUSTOMER(false,true,true,true,"dse"),
    DSE_DEALER(false,true,true,true,"dse"),
    COUPON(true,true,true,true,"coupon"),
    GMLABOROPCODE(true,true,true,true,"vps","VEHICLEPROFILESERVICE"),
    SALES_ORDER(true,true,true,true,"partTrade"),
    STOCK(false,false,true,true,"vi"),
    DEALS_BY_VEHICLEID(true,true,true,true,"sales/core","DEALSERVICE"),
    USER(true,true,true,true,"settings"),
    CUSTOMER_MINIMAL_SEARCH(true,true,true,true,"cms"),
    TENANT_USER_MINIMAL(true,true,true,true,"settings"),
    DEALER_ACCESSIBLE_USER_MINIMAL(true,true,true,true,"settings"),
    VEHICLES_BY_LAST_8_VIN(true,true,true,true,"vi"),
    VEHICLE_INTERIOR_COLOR(true,true,true,true,"vi"),
    ANALYTICS_VI(true,false,true,true,"analytics","ANALYTICS"),
    ANALYTICS_DEAL(true,false,true,true,"analytics","ANALYTICS"),
    VEHICLE_EXTERIOR_COLOR(true,true,true,true,"vi"),
    CAUSE_CODE(false,false,true,true,"vps"),
    LEAD_BY_ID(true,true,true,true,"crmlead","CRMLEADSERVICE"),
    DEALER_ACCESSIBLE_USER_MINIMALV3(true,true,true,true,"userservice","USERSERVICE"),
    VEHICLE_MODEL_NUMBER(true,false,true,true,"vi"),
    EXPENSE_CODE(false,false,true,true,"vps"),
    VEHICLE_EXTERIOR_COLOR_HEXCODE(true,true,true,true,"vi"),
    NATURE_CODE(false,false,true,true,"vps"),
    DEAL_TAX_COUNTY(true,false,true,true,"sales/core","DEALSERVICE"),
    EMPLOYEE(true,true,true,true,"userservice","USERSERVICE"),
    VEHICLES_ID_BY_LAST_8_VIN(true,true,true,true,"vi"),
    FEEV2(true,true,true,true,"fee"),
    TAGS_BY_SEARCH(true,true,true,true,"crmtask","CRMTASK"),
    DEAL_TAX_STATE(true,false,true,true,"sales/core","DEALSERVICE"),
    DRAWERS(true,true,true,true,"wms"),
    SOURCECODE(true,true,true,true,"wms"),
    VEHICLE_CUSTOM_FIELD(true,true,true,true,"vi"),
    ACCOUNTS_COST_CENTER(false,false,true,true,"settings"),
    TAG_BY_NAME(true,true,true,true,"crmtask","CRMTASK"),
    LEAD_BY_NAME(true,false,true,true,"crmlead","CRMLEADSERVICE"),
    COST_CENTER(true,false,true,true,"settings"),
    SHELVES(true,true,true,true,"wms"),
    DEAL_TAX_CITY(true,false,true,true,"sales/core"),
    DEALER_ACCESSIBLE_USER_MINIMALV2(true,true,true,true,"settings"),
    CAMPAIGN(true,true,true,true,"campaignservice","CAMPAIGN_SERVICE"),
    PARTINVENTORYWITHMASTER(true,false,true,true,"wms"),
    WARRANTY_CLAIM_ASSET(true,true,true,true,"service-warranty-service"),
    DEAL_CUSTOMER_STATE(true,false,true,true,"sales/core","DEALSERVICE"),
    DEAL_CUSTOMER_CITY(true,false,true,true,"sales/core","DEALSERVICE"),
    DEAL_CUSTOMER_COUNTY(true,false,true,true,"sales/core","DEALSERVICE"),
    FRANCHISE_ASSET(true,false,true,true,"/accounting","ACCOUNTINGSERVICE"),
    COST_ADJUSTMENT(true,true,true,true,"sales/settings","SALESSETTINGS"),
    DUE_BILLS(true,true,true,true,"sales/settings","SALESSETTINGS"),
    COST_ADJUSTMENT_1(true,true,true,true,"sales/settings","SALESSETTINGSSERVICE"),
    COST_ADJUSTMENT_2(true,true,true,true,"sales/settings","SALESSETTINGS"),
    COST_ADJUSTMENT_3(true,true,true,true,"sales/settings","SALESSETTINGSSERVICE"),
    COST_ADJUSTMENT_6(true,true,true,true,"sales/settings/preference","salessettingsservice"),
    DUE_BILL_SETUP(true,true,true,true,"sales/settings/preference","salessettingsservice"),
    COST_ADJUSTMENT_SETUP(true,true,true,true,"sales/settings/preference","salessettingsservice"),
    LENDERS(true,true,true,true,"sales/settings/preference","salessettingsservice"),
    ROLE(true,true,true,true,"sales/settings/preference","salessettingsservice"),
    VENDORS(true,true,true,true,"sales/settings/preference","salessettingsservice"),
    FNI(true,true,true,true,"sales/settings/preference","salessettingsservice"),
    COREPARTINVENTORY(true,true,true,true,"wms","WMSSERVICE"),
    COREPARTINVENTORYWITHMASTER(true,true,true,true,"wms","WMSSERVICE"),
    ASSIGNEE_USER_BY_PERSONA(true,true,true,true,"userservice","USERSERVICE"),
    CRM_SETUP_SALES_LEAD_STAGE(true,false,true,true,"crmsetup","CRMSETUP"),
    CRM_SETUP_SERVICE_LEAD_STAGE(true,false,true,true,"crmsetup","CRMSETUP"),
    CRM_SETUP_PARTS_LEAD_STAGE(true,false,true,true,"crmsetup","CRMSETUP"),
    CRM_SETUP_LEAD_CUSTOM_STAGE(true,false,true,true,"crmsetup","CRMSETUP"),
    CRM_SETUP_LEAD_SOURCES(true,false,true,true,"crmsetup","CRMSETUP"),
    VEHICLE_MAKES(true,false,true,true,"vi","VEHICLEINVENTORYSERVICE"),
    TENANT_USER_MINIMALV2(true,true,true,true,"userservice","USERSERVICE"),
    TEAMS_AND_ASSIGNEE_USER_BY_PERSONA(true,true,true,true,"userservice","USERSERVICE"),
    CRM_SETUP_LEAD_SOURCE_GROUP(true,true,true,true,"crmsetup","CRMSETUP"),
    VEHICLE_PROVIDER_ORDER_STAUS(true,false,true,true,"vi","VEHICLEINVENTORYSERVICE"),
    VEHICLE_PROVIDER_ORDER_STATUS(true,false,true,true,"vi","VEHICLEINVENTORYSERVICE"),
    TESTINGWARRANTY(false,false,true,true,"/vps","VEHICLEPROFILESERVICE");

    private final boolean searchSupported;
    private final boolean idSupported;
    private final boolean numberSupported;
    private final boolean hasAccessToLookup;
    @NotNull
    private final String forwardAppRoot;
    @NotNull
    private final String serviceName;
    public static final String DEFAULT_HOST_SERVICE = "CONFIG_HOST_SERVICE";

    WorkspaceLookupAsset(

            boolean searchSupported, boolean idSupported, boolean numberSupported, boolean hasAccessToLookup,
            String forwardAppRoot ) {

        this.searchSupported = searchSupported;
        this.idSupported = idSupported;
        this.hasAccessToLookup = hasAccessToLookup;
        this.forwardAppRoot = forwardAppRoot;
        this.numberSupported = numberSupported;
        this.serviceName = DEFAULT_HOST_SERVICE;
    }
}
