package com.tekion.lookuphelper;

import com.tekion.lookuphelper.dto.request.*;
import com.tekion.lookuphelper.dto.response.LookupEntity;
import com.tekion.lookuphelper.dto.response.LookupSearchResponse;

import java.util.List;
import java.util.Map;


public interface LookupService<T extends ILookupAsset> {

    /**
     * @return all the supported types, supported by the lookup
     */
    List<ILookupAsset> getSupportedLookupAssets();

    /**
     * This is a method which takes an LookupRequestByIds and based on the assetType resolves the ids and
     * searches the data
     *
     * @param lookupRequestByIds is take list of ids and assetType of the asset to resolve
     * @return List of Resolved entities
     */
    List<LookupEntity> lookupByIds(LookupRequestByIds lookupRequestByIds);

    /**
     * @param searchRequest esSearch request for the assetType
     * @return List of resolved objects
     */
    LookupSearchResponse lookupBySearch(LookupRequestBySearch searchRequest);

    List<LookupEntity> lookupByNumber(LookupRequestByNumbers request);

    /**
     * @param bulkLookupRequestByIds is resolve against lookup requests
     * @return map of asset type against resolved objects
     */
    Map<T, List<LookupEntity>> bulkLookupByIds(BulkLookupRequestByIds bulkLookupRequestByIds);


    /**
     * @param bulkLookupRequestBySearch which is list of lookupRequestBySearch use this and resolve it using assetType
     * @return map of asset type against resolved objects
     */
    Map<T, LookupSearchResponse> bulkLookupBySearch(BulkLookupRequestBySearch bulkLookupRequestBySearch);


    Map<T, List<LookupEntity>> bulkLookupByNumber(BulkLookupRequestByNumbers bulkLookupRequestByNumbers);
}
