package com.tekion.lookuphelper;


public interface ILookupAsset {


    String name();

    boolean isSearchSupported();

    boolean isIdSupported();

    boolean isNumberSupported();

}
