package com.tekion.lookuphelper.lookupConsumerClient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.tekion.core.utils.TCollectionUtils;
import com.tekion.core.utils.TJsonUtils;
import com.tekion.lookupconsumer.LookupConsumerService;
import com.tekion.lookupconsumer.beans.LookupRequest;
import com.tekion.lookuphelper.LookupConsumerAsset;
import com.tekion.lookuphelper.dto.request.*;
import com.tekion.lookuphelper.dto.response.LookupEntity;
import com.tekion.lookuphelper.dto.response.LookupSearchResponse;
import com.tekion.lookuphelper.utils.TConstants;
import com.tekion.tekionconstant.lookupconsumer.LookupAsset;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;

import static com.tekion.lookuphelper.utils.LookupUtils.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class LookupServiceClient {

    private final LookupConsumerService lookupConsumerService;

    public Map<LookupConsumerAsset, List<LookupEntity>> lookupByIds(BulkLookupRequestByIds bulkLookupRequestByIds) {
        Map<LookupAsset, LookupRequest> requestMap = new HashMap<>();
        Map<LookupAsset, JsonNode> lookupResponse = new HashMap<>();
        Map<LookupConsumerAsset, List<LookupEntity>> finalResponse = new HashMap<>();
        for (LookupRequestByIds lookupRequestByIds : TCollectionUtils.nullSafeList(
                bulkLookupRequestByIds.getLookupRequestByIds())) {
            LookupAsset lookupAsset = newLookupAssetToOldLookupAsset(lookupRequestByIds.getAssetType());
            LookupRequest lookupRequest = new LookupRequest();
            lookupRequest.setIds(lookupRequestByIds.getIds());
            requestMap.put(lookupAsset, lookupRequest);
        }
        try {
            lookupResponse = lookupConsumerService.lookupIds(requestMap);
        } catch (Exception e) {
            log.error("Exception in lookupConsumerService.lookupIds ", e);
        }
        for (LookupAsset lookupAsset : lookupResponse.keySet()) {
            finalResponse.put(oldLookupAssetToNewLookupAsset(lookupAsset),
                    lookupResponseMapper(lookupResponse.get(lookupAsset), lookupAsset));
        }
        return finalResponse;
    }

    public Map<LookupConsumerAsset, List<LookupEntity>> lookupByNumbers(
            BulkLookupRequestByNumbers bulkLookupRequestByNumbers) {
        Map<LookupAsset, Collection<String>> requestMap = new HashMap<>();
        Map<LookupAsset, JsonNode> lookupResponse = new HashMap<>();
        Map<LookupConsumerAsset, List<LookupEntity>> finalResponse = new HashMap<>();
        for (LookupRequestByNumbers lookupRequestByNumbers : TCollectionUtils.nullSafeList(
                bulkLookupRequestByNumbers.getLookupRequestByNumbers())) {
            LookupAsset lookupAsset = newLookupAssetToOldLookupAsset(lookupRequestByNumbers.getAssetType());
            requestMap.put(lookupAsset, lookupRequestByNumbers.getNumbers());
        }
        try {
            lookupResponse = lookupConsumerService.lookupNumbers(requestMap);
        } catch (Exception e) {
            log.error("Exception in lookupConsumerService.lookupNumbers", e);
        }
        for (LookupAsset lookupAsset : lookupResponse.keySet()) {
            finalResponse.put(oldLookupAssetToNewLookupAsset(lookupAsset),
                    lookupResponseMapper(lookupResponse.get(lookupAsset), lookupAsset));
        }
        return finalResponse;
    }

    public Map<LookupConsumerAsset, LookupSearchResponse> lookupBySearch(
            BulkLookupRequestBySearch bulkLookupRequestBySearch) {
        Map<LookupAsset, JsonNode> requestMap = new HashMap<>();
        Map<LookupAsset, JsonNode> lookupResponse = new HashMap<>();
        Map<LookupConsumerAsset, LookupSearchResponse> finalResponse = new HashMap<>();
        for (LookupRequestBySearch lookupRequestBySearch : TCollectionUtils.nullSafeList(
                bulkLookupRequestBySearch.getLookupRequestBySearch())) {
            requestMap.put(newLookupAssetToOldLookupAsset(lookupRequestBySearch.getAssetType()),
                    TJsonUtils.getDefaultSharedMapper().valueToTree(lookupRequestBySearch.getSearchRequest()));
        }
        try {
            lookupResponse = lookupConsumerService.lookupSearchRequest(requestMap);
        } catch (Exception e) {
            log.error("Exception in lookupConsumerService.lookupSearch ", e);
        }
        for (LookupAsset lookupAsset : lookupResponse.keySet()) {
            finalResponse.put(oldLookupAssetToNewLookupAsset(lookupAsset),
                    lookupSearchResponseMapper(lookupResponse.get(lookupAsset)));
        }
        return finalResponse;
    }

    private List<LookupEntity> lookupResponseMapper(JsonNode data, LookupAsset lookupAsset) {
        List<LookupEntity> finalResponse = new ArrayList<>();
        if (!data.isNull() && data.has(TConstants.ENTITIES)) {
            data = data.get(TConstants.ENTITIES);
        }
        if (!data.isNull() && data.isArray()) {
            Iterator<JsonNode> jsonNodeIterator = data.elements();
            while (jsonNodeIterator.hasNext()) {
                JsonNode arrayNode = jsonNodeIterator.next();
                if (arrayNode.has(TConstants.DATA)) {
                    try {
                        LookupEntity lookupEntity = TJsonUtils.getDefaultSharedMapper()
                                                              .treeToValue(arrayNode, LookupEntity.class);
                        finalResponse.add(lookupEntity);
                    } catch (JsonProcessingException e) {
                        log.error("Unable to convert lookupSearch request", e);
                    }
                } else {
                    try {
                        Object object = TJsonUtils.getDefaultSharedMapper().treeToValue(arrayNode, Object.class);
                        String id;
                        String displayValue = null;
                        switch (lookupAsset) {
                            case CUSTOMER:
                                id = arrayNode.has(TConstants.ID) ? arrayNode.get(TConstants.ID).asText() : null;
                                displayValue = arrayNode.has(TConstants.DISPLAY_ID) ? arrayNode
                                        .get(TConstants.DISPLAY_ID).asText() : null;
                                break;
                            default:
                                id = arrayNode.has(TConstants.ID) ? arrayNode.get(TConstants.ID).asText() : null;
                        }
                        LookupEntity lookupEntity = new LookupEntity<>(id, displayValue, object);
                        finalResponse.add(lookupEntity);
                    } catch (JsonProcessingException e) {
                        log.error("Unable to convert lookupSearch request", e);
                    }
                }
            }
        }
        return finalResponse;
    }
}
