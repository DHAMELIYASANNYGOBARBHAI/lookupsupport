package com.tekion.lookuphelper;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class WorkspaceLookupServiceProvider {

    public final Map<WorkspaceLookupAsset, AbstractWorkspaceLookupService> assetVsServiceMap;

    @Autowired
    public WorkspaceLookupServiceProvider(List<AbstractWorkspaceLookupService> lookupServices) {
        Map<WorkspaceLookupAsset, AbstractWorkspaceLookupService> assetVsServiceHelperMap = new HashMap<>();
        lookupServices.forEach(lookupService -> {
            List<WorkspaceLookupAsset> lookupAssets = lookupService.getSupportedLookupAssets();
            lookupAssets.forEach(key -> {
                assetVsServiceHelperMap.put(key, lookupService);
            });
        });
        this.assetVsServiceMap = assetVsServiceHelperMap;
    }

    public AbstractWorkspaceLookupService getServiceForLookupAsset(WorkspaceLookupAsset lookupAsset) {
        return this.assetVsServiceMap.get(lookupAsset);
    }
}

